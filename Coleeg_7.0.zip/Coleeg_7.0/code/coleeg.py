__version__ = 7.0

# importing modules
import mne
mne.set_log_level('WARNING')
import numpy as np
from datetime import datetime, timedelta, timezone
import pytz
import scipy.io
import pickle
import random
from scipy.fft import dct
import sys
import time
import os
from IPython import get_ipython
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Activation, Lambda, Permute
from tensorflow.keras import activations
from tensorflow.keras.layers import Dense, Dropout, Flatten, Conv3D, InputLayer, Conv1D
from tensorflow.keras.layers import MaxPooling3D, MaxPooling1D,AveragePooling3D, AveragePooling1D
from tensorflow.keras.layers import Conv2D, LSTM
from tensorflow.keras.layers import Reshape, GlobalAveragePooling1D, GlobalAveragePooling2D,TimeDistributed, Conv2D
from tensorflow.keras import backend as K
from tensorflow.keras.constraints import max_norm
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.layers import MaxPooling2D, AveragePooling2D
from tensorflow.keras.layers import Input
from tensorflow.keras.layers import SeparableConv2D, DepthwiseConv2D
from tensorflow.keras.layers import SpatialDropout2D
from tensorflow.keras.models import Model
from tensorflow.keras.layers import concatenate
from tensorflow.keras.losses import binary_crossentropy, categorical_crossentropy
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import Callback
from tensorflow.keras import regularizers
from tensorflow.keras.metrics import Precision, Recall, AUC
from sklearn.utils import class_weight
from imblearn.over_sampling import SMOTE

from functools import partial

from sklearn.metrics import classification_report, confusion_matrix, f1_score
import seaborn as sns

from tensorflow.keras.callbacks import EarlyStopping

import keras
import tensorflow as tf
import gc
import matplotlib.pyplot as plt
import csv
import re
import json
from PyEMD import EMD
import pandas as pd
import glob
from io import StringIO
from scipy.signal import resample_poly

########################## defining parameters ############################
this = sys.modules[__name__]
COLEEG = sys.modules[__name__]

training_metrics = ['loss', 'accuracy', 'cohen_kappa', 'specificity', 'sensitivity', 'precision', 'recall', 'auc', 'f1score']
validation_metrics = ['loss', 'accuracy', 'cohen_kappa', 'specificity', 'sensitivity', 'precision', 'recall', 'auc', 'f1score']
this.METRICS = [f"training_{m}" for m in training_metrics] + [f"validation_{m}" for m in validation_metrics]

this.DATASETS = ['physionet', 'ttk', 'bcicomptIV2a', 'chbmit','mitbih', 'incart','ptbxl']
this.DATASET_NAMES = {'bcicomptIV2a':'BCI Competition IV-2a', 'physionet':'Physionet','ttk':'MTA-TTK', 'chbmit':'CHB-MIT', 'mitbih':'MIT-BIH', 'incart':'INCART','ptbxl':'PTB-XL'}

this.Sample_Freqs = {'physionet':160, 'ttk':500, 'bcicomptIV2a':250, 'chbmit':256,'mitbih':360,'incart':257,'ptbxl':500}
this.MODELS = ['Basic','CNN1D','CNN1DZ', 'ECG1D','ECG1DA','EEGNet', 'ShallowConvNet', 'DeepConvNet','CNN2D','CNN3D', 'TimeDist']
this.chbmit_channel_names = ['FP1-F7', 'F7-T7', 'T7-P7', 'P7-O1', 'FP1-F3', 'F3-C3', 'C3-P3', 'P3-O1', 'FP2-F4', 'F4-C4', 'C4-P4', 'P4-O2', 'FP2-F8', 'F8-T8', 'T8-P8', 'P8-O2', 'FZ-CZ', 'CZ-PZ', 'P7-T7', 'T7-FT9', 'FT9-FT10', 'FT10-T8']
###########################################################################

####################### defining CohenKappa Class ##########################
class CohenKappa(tf.keras.metrics.Metric):
    def __init__(self, num_classes, name='cohen_kappa', **kwargs):
        super(CohenKappa, self).__init__(name=name, **kwargs)
        self.num_classes = num_classes
        self.conf_mtx = self.add_weight(name='conf_mtx', shape=(num_classes, num_classes), initializer='zeros')

    def update_state(self, y_true, y_pred, sample_weight=None):
        y_true = tf.argmax(y_true, axis=1)
        y_pred = tf.argmax(y_pred, axis=1)
        confusion = tf.cast(tf.math.confusion_matrix(y_true, y_pred, num_classes=self.num_classes), dtype=tf.float32)
        self.conf_mtx.assign_add(confusion)

    def result(self):
        sum_diag = tf.reduce_sum(tf.linalg.diag_part(self.conf_mtx))
        sum_rows = tf.reduce_sum(self.conf_mtx, axis=0)
        sum_cols = tf.reduce_sum(self.conf_mtx, axis=1)
        total_samples = tf.reduce_sum(sum_rows)

        po = sum_diag / total_samples
        pe = tf.reduce_sum(sum_rows * sum_cols) / (total_samples ** 2)
        kappa = (po - pe) / (1 - pe)

        return kappa

    def reset_state(self):
        # Reset the confusion matrix
        self.conf_mtx.assign(tf.zeros_like(self.conf_mtx))
############################################################################

############################ Function Start #################################
def sensitivity(y_true, y_pred):
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
    return true_positives / (possible_positives + K.epsilon())
############################ Function End #################################

############################ Function Start #################################
def specificity(y_true, y_pred):
    true_negatives = K.sum(K.round(K.clip((1 - y_true) * (1 - y_pred), 0, 1)))
    possible_negatives = K.sum(K.round(K.clip(1 - y_true, 0, 1)))
    return true_negatives / (possible_negatives + K.epsilon())
############################ Function End #################################

############################ Function Start ################################
def set_metrics(n_outputs=4):

  this.MODEL_METRICS = []
  if any(item in ['training_accuracy','validation_accuracy'] for item in this.METRICS):
    this.MODEL_METRICS.append('accuracy')
  if any(item in ['training_kappa','validation_cohen_kappa'] for item in this.METRICS):
    this.MODEL_METRICS.append(CohenKappa(num_classes=n_outputs))
  if any(item in ['training_specificity','validation_specificity'] for item in this.METRICS):
    this.MODEL_METRICS.append(specificity)
  if any(item in ['training_sensitivity','validation_sensitivity'] for item in this.METRICS):
    this.MODEL_METRICS.append(sensitivity)
  # Adding Precision
  if any(item in ['training_precision','validation_precision'] for item in this.METRICS):
    this.MODEL_METRICS.append(Precision(name='precision'))
  # Adding Recall
  if any(item in ['training_recall','validation_recall'] for item in this.METRICS):
    this.MODEL_METRICS.append(Recall(name='recall'))
  # Adding AUC implementation
  if any(item in ['training_auc','validation_auc'] for item in this.METRICS):
    # Using multi_label=True to support multi-class arrhythmia classification
    # This aligns with the macro-averaging discussed in the paper
    this.MODEL_METRICS.append(AUC(name='auc', multi_label=True))
  if any(item in ['training_f1score','validation_f1score'] for item in this.METRICS):
    # Using multi_label=True to support multi-class arrhythmia classification
    # This aligns with the macro-averaging discussed in the paper
    this.MODEL_METRICS.append(keras.metrics.F1Score(average='macro', name='f1score'))
  return
#############################################################################

############################ Function Start ################################
def coleeg_version():
  print(this.__version__)
############################ Function End #################################

############################ Function Start ################################
def set_time_zone(zone):
  this.TIME_ZONE = pytz.timezone(zone)
############################ Function End #################################

############################ Function Start ################################
def set_data_folder(folder):
  this.DATA_FOLDER = folder
  os.makedirs(this.DATA_FOLDER, exist_ok=True)
  this.RESULT_FOLDER = f'{this.DATA_FOLDER}/results'
  this.PLOT_FOLDER = f'{this.DATA_FOLDER}/plots'
  this.BARPLOT_FOLDER = f'{this.DATA_FOLDER}/barplots'
  this.CROSS_TEST_FOLDER = f'{this.DATA_FOLDER}/cross-tests'
  return
############################ Function End #################################

############################ Function Start ################################
def set_content_folder(dataset):
  if dataset in ['chbmit']:
    this.CONTENT_FOLDER = f'{this.DATA_FOLDER}/datasets'
  else:
    if 'google.colab' in sys.modules:
      this.CONTENT_FOLDER = '/content'
    else:
      this.CONTENT_FOLDER = f'{this.DATA_FOLDER}/content'
  os.makedirs(this.CONTENT_FOLDER, exist_ok=True)
  return
############################ Function End #################################


############################ Function Start #################################
def coleeg_info():
  info = """
* Coleeg is an open source initiative for collaborating on making a piece of software for investigating the use of Neural Networks in EEG signal classification on different datasets.

* License GPL V2.0

## How to install Coleeg to your google drive

  1- Download Coleeg_5.0.zip and extract it.
  2- Copy Coleeg5.0 folder to the root of your google drive.
  3- Open RunColeeg_5.0.ipynb which is inside Coleeg5.0 folder.
  4- Grant permissions for the notebook to enable its access your google drive.
  5- The data needed for Coleeg will be located in the directory ColeegData in the root of your google drive.
  6- To use Colab online, choose Connect>Connect to a hosted runtime.
  7- To use your local machine, copy Coleeg4 folder to your home (i.e. personal) folder.
  Local runtime was tested in Linux (Kubuntu 22.04)
  8- Run Colab_local script using the command (bash Colab_Local) and copy the generated url.
  9- Run RunColeeg_5.0.ipynb from google drive (not the the one on your home folder).
  10- Choose Connect>Connect to a local runtime, then paste the url and select connect.

## What's new in Version 7.0
  * renaming plot_trial function to plot_segment and adopting the name segments instead of trials to avoid confusion.
  * renaming keep_bands, keep_subjects, keep_channels, and keep_classes functions to select_bands, select_subjects, select_channels, and select_classes
  * Adding more control over plotting functions, like hiding titles and legend and controlling figure sizes.
  * Installing required python modules for local machine in ColeegData/lib folder to avoid conflict with local modules.
  * Adding Recall, Precision, and Area Under Curve (AUC) metrics.
  * Adding testing report for Recall, Precision, F-Score, Accuracy, support and accuracy for each class.
  * Saving plots for confusion matrix (as pdf files), class counts (per fold), and trained models in the results folder.
  * Ability to continue previous uncompleted folds in model training.
  * Ability to set the seeds for random number generation in the Python modules used in model training, with the ability to force deterministic calculations in the hardware used.
  * Adding Synthetic Minority Over-sampling Technique (SMOTE) for data augmentation.
  * Adding Focal-Loss to model loss functions.
  * Adding early stopping.
  * Adding the ability to assign one fold for testing.
  * Various code fixes and UI refinements.

## What's new in Version 6.0
  * Adding MIT-BIH Arrhythmia Database.
    Link: https://physionet.org/content/mitdb/1.0.0/
  * Adding plot_trial() function to plot time segments in data_x.
    Segment selection can be random or specified.
  * Adding two new models for ECG classification, which are
    - ECG1D: created by Alnaanah
    - ECG1DA: Emplementing the model in the paper:
      "Classifying Cardiac Arrhythmia from ECG Signal Using 1D CNN Deep Learning Model" by Adel A. Ahmed
  * Fixing shuffle option in model evaluation.
    It is now done for all data_x array at the beginning  for evaluation function
  * Fixing balance() function to deal with data_x array where not all subjects have the the same classes.
  * Renaming unzip_dataset() function to download_dataset() and updating it.
  * Adding show_class_stats() function to show MIN, MAX, AND sum values for classes per each subject.
  * Modify balance() function to set maximum number of classes per each class per subject.
  * Fix plot_bar() and plot_multibar() function when align_to_subject option is False.
  * Adding model list (COLEEG.MODEL) to coleeg variables.
  * Implementing class weights in model evaluation, this helps for unbalanced classes.

## What's new in Version 5.0
  * Reorganizing the interface and using INFO dictionary to store paramters.
  * Rewriting the plotting functions to have more control over their labels.
  * The parameters used in Coleeg are now stored in info.json file.
  * data_x, data_y, and data_subject_index can be saved and loaded.
  * Bar and multi-bar plots are added.
  * Reading the interictal data for GHB-MIT dataset is added.
  * CNN1DZ model for seizure detection is added.
  * Empirical Mode Decomposition (EMD) is added.
  * Fixing select_subjects
  * Many other minor fixes and enhancements.

## What's new in Version 4.1
  * Installing specific versions of mne and tensorflow to solve issues appear when using new versions.

## What's new in Version 4.0
  * Adding CHB-MIT Scalp EEG Database.
  * Link: https://physionet.org/content/chbmit/1.0.0/
  * Some enhancements and bug fixes.

## What's new in Version 3.2
  * Some bugs are fixed
  * Dataset files are downloaded automatically.
  * Coleeg folder structure is changed. Coleeg code and data are in separate folders.
  * Specific python packages are installed in local runtime to guarantee compatibility.

## What's new in Version 3.0
  * The code is cleaner and more intuitive
  * Support of local runtime is added.
  * More metrics are supported and they can be selected during initialization, these metrics are:
    loss, accuracy, cohen_kappa, specificity, sensitivity
  * local timezone can be set.
  * A subset of classes and subjects can be selected for evaluation.
  * Plots of the resutls can be displayed and saved as pdf files in resutls/plots folder.
  * The result average value for last epochs can can be displayed and saved in the results folder.
  * The time for evaluation can be displayed and saved in the results folder
  * Validation can be done for dct and fft transforms of the origianl time signals.



## Links:

Some database links:
* Physionet:
  https://physionet.org/static/published-projects/eegmmidb/eeg-motor-movementimagery-dataset-1.0.0.zip
* BCI competetion IV-2a:
  http://www.bbci.de/competition/iv/#download
  http://www.bbci.de/competition/iv/results/#labels
* CHB-MIT:
  https://physionet.org/content/chbmit/1.0.0/
* TTK dataset is a private dataset and (up to now) not available publicly.

Human activity recognition (similar problem to EEG classification)
* https://machinelearningmastery.com/how-to-develop-rnn-models-for-human-activity-recognition-time-series-classification/

Example on using CNN1D for reading thoughts 
* https://medium.com/@justlv/using-ai-to-read-your-thoughts-with-keras-and-an-eeg-sensor-167ace32e84a

Video classification approaches
* http://francescopochetti.com/video-classification-in-keras-a-couple-of-approaches/

MNE related links
* https://mne.tools/stable/auto_examples/time_frequency/plot_time_frequency_global_field_power.html?highlight=alpha%20beta%20gamma

* https://mne.tools/stable/auto_tutorials/preprocessing/plot_30_filtering_resampling.html#sphx-glr-auto-tutorials-preprocessing-plot-30-filtering-resampling-py

K-Fold cross-validation
* https://androidkt.com/k-fold-cross-validation-with-tensorflow-keras/

Fix memory leak in Colab
* https://github.com/tensorflow/tensorflow/issues/31312
* https://stackoverflow.com/questions/58137677/keras-model-training-memory-leak

Difference between Conv2D DepthWiseConv2D and SeparableConv2D
* https://amp.reddit.com/r/MLQuestions/comments/gp2pj9/what_is_depthwiseconv2d_and_separableconv2d_in/

Model difinition for EEGNet, ShallowConvNet, DeepConvNet was taken from the following link:
* https://github.com/rootskar/EEGMotorImagery


Customize Your Keras Metrics (how sensitivity and specificity are defined)
https://medium.com/@mostafa.m.ayoub/customize-your-keras-metrics-44ac2e2980bd

CHB-MIT Scalp EEG Database
https://physionet.org/content/chbmit/1.0.0/
  """
  print(info)
  return
############################ Function End #################################

############################ Function Start #################################
def get_data_ttk(Subjects = np.arange(1,26), Exclude=None, data_path=None,
                        Bands=None, resample_freq=None, Data_type=np.float32, tmin=0, tmax=2,Baseline=None, notch_freqs=None):

  if data_path is None:
    data_path=f'{this.DATA_FOLDER}/datasets/TTK/'

  # First subject in Subjects and Exclude has number = 1

  if Exclude is not None:
    print('Excluded Subjects are '+ str(Exclude))
    Subjects = np.delete(Subjects,np.isin(Subjects,Exclude))
  else:
    print('No subject excluded')

  subject_count = 0
  data_subject_index = np.zeros((len(Subjects),2)).astype(np.int32) # starting data index for each subject and its number
  data_subject_index[:,1] = Subjects

  data_count = 0
  for sub_index, subject in enumerate(Subjects):
    print(f'\rLoading subject [{sub_index+1}], Total subjects [{len(Subjects)}]', end = '')
    data_subject_index[subject_count,0] = data_count
    subject_count+=1   
    if subject == 1:
      raw_fnames = [f'{data_path}subject{subject:02d}/rec01.vhdr', f'{data_path}subject{subject:02d}/rec02.vhdr', f'{data_path}subject{subject:02d}/rec03.vhdr']
      raw = mne.io.concatenate_raws([mne.io.read_raw_brainvision(f, preload=True, verbose=False) for f in raw_fnames])
    elif subject == 9:
      # rec02.vhdr is skipped because it is has a problem
      raw_fnames = [f'{data_path}subject{subject:02d}/rec01.vhdr']
      raw = mne.io.concatenate_raws([mne.io.read_raw_brainvision(f, preload=True, verbose=False) for f in raw_fnames])
    elif subject == 10:
      file_name = f'{data_path}subject{subject:02d}/rec01-uj.vhdr'
      raw = mne.io.read_raw_brainvision(file_name, preload=True, verbose=False)
    elif subject == 17:
      raw_fnames = [f'{data_path}subject{subject:02d}/rec01.vhdr', f'{data_path}subject{subject:02d}/rec02.vhdr']
      raw = mne.io.concatenate_raws([mne.io.read_raw_brainvision(f, preload=True, verbose=False) for f in raw_fnames])
    else:
      file_name = f'{data_path}subject{subject:02d}/rec01.vhdr'
      raw = mne.io.read_raw_brainvision(file_name, preload=True, verbose=False)

    raw.load_data(verbose=False) # needed for filteration
    if resample_freq is not None:
      raw.resample(resample_freq, npad="auto")
    if notch_freqs is not None:
        raw.notch_filter(notch_freqs)
    event_dict = {'Stimulus/S  1':1, 'Stimulus/S  5':2, 'Stimulus/S  7':3, 'Stimulus/S  9':4, 'Stimulus/S 11':5} 
    events, _ = mne.events_from_annotations(raw,event_id = event_dict, verbose=False)
    if Bands is not None:
      # Getting epochs for different frequncy bands   
      for band, (fmin, fmax) in enumerate(Bands):
        raw_bandpass = raw.copy().filter(fmin, fmax, fir_design='firwin',verbose=False)
        epochs = mne.Epochs(raw_bandpass, events, event_id=event_dict,baseline=Baseline, tmin=tmin, tmax=tmax, preload=True, event_repeated = 'drop',verbose=False)
        if not 'bands_data' in locals():
          D_SZ = epochs.get_data(copy=False).shape
          bands_data = np.empty((D_SZ[0],D_SZ[2],D_SZ[1],len(Bands)))
        # Swapping dimensions from (epoch, channel, sample) to (epoch, sample, channel)
        bands_data[:,:,:,band] = epochs.get_data(copy=True).transpose(0,2,1) 
        del raw_bandpass
    else:
      epochs = mne.Epochs(raw, events, event_id=event_dict,baseline=Baseline, tmin=tmin, tmax=tmax, preload=True, event_repeated = 'drop',verbose=False)
      bands_data = epochs.get_data(copy=True)
      SZ = bands_data.shape
      # Swapping dimensions from (epoch, channel, sample) to (epoch, sample, channel)
      bands_data = bands_data.transpose(0,2,1).reshape(SZ[0],SZ[2],SZ[1],1)
    

    tmp_y = epochs.events[:,2]

    # Adjusting events numbers to be compatible with output classes numbers
    tmp_y = tmp_y - 1

    max_epochs = (284+65*4)
    SZ = bands_data.shape      
    # Creating output x and y matrices
    if not 'data_x' in locals():
      data_x = np.empty((max_epochs*len(Subjects),SZ[1],SZ[2],SZ[3]),dtype=Data_type)
      data_y = np.empty(max_epochs*len(Subjects),dtype=np.uint16)

    ## adjusting data type
    bands_data = bands_data.astype(Data_type)
    tmp_y = tmp_y.astype(np.uint16)

  
    data_x[data_count:data_count + SZ[0],:,:,:] = bands_data
    data_y[data_count:data_count + SZ[0]] = tmp_y

    data_count+=SZ[0]

    del raw, epochs, tmp_y, bands_data # saving memory 


  data_x = data_x[0:data_count,:,:,:]
  data_y = data_y[0:data_count]

  return data_x, data_y, data_subject_index

########################### Function End ####################################


############################ Function Start #################################
def get_data_chbmit(Subjects = np.arange(1,25), Exclude=None, data_path=None,Bands=None, tmin = 0, tmax =2,gap=None, segment_max=None,  resample_freq=None, Data_type=np.float32,Baseline=None, notch_freqs=None):
  assert gap is not None
  assert segment_max is not None

  period = int(tmax - tmin) # period in seconds

  included_data = get_chbmit_array(gap)

  selected_ch_names = this.chbmit_channel_names

  #selected_ch_names= ['FP1-F7', 'F7-T7', 'T7-P7', 'P7-O1', 'FP1-F3', 'F3-C3', 'C3-P3', 'P3-O1', 'FP2-F4', 'F4-C4', 'C4-P4', 'P4-O2', 'FP2-F8', 'F8-T8', 'T8-P8', 'P8-O2', 'FZ-CZ', 'CZ-PZ', 'P7-T7', 'T7-FT9', 'FT9-FT10', 'FT10-T8']

  # last 4 channels where removed to be able to read selected files for interactal for subject 13
  #selected_ch_names= ['FP1-F7', 'F7-T7', 'T7-P7', 'P7-O1', 'FP1-F3', 'F3-C3', 'C3-P3', 'P3-O1', 'FP2-F4', 'F4-C4', 'C4-P4', 'P4-O2', 'FP2-F8', 'F8-T8', 'T8-P8', 'P8-O2', 'FZ-CZ', 'CZ-PZ']

  if data_path is None: data_path=f'{this.CONTENT_FOLDER}/physionet.org/files/chbmit/1.0.0/'

  # First subject in Subjects and Exclude has number = 1



  if Exclude is not None:
    print('Excluded Subjects are '+ str(Exclude))
    Subjects = np.delete(Subjects,np.isin(Subjects,Exclude))
    #for i in sorted(Exclude, reverse=True):
      #del included_data[i-1]
  else:
    print('No subject excluded')

  #included_data = [included_data[i - 1] for i in Subjects]

  sampling_freq = resample_freq if resample_freq else 256

  # caculating number of epochs for the included data
  epoch_count = 0
  for subject in Subjects:
    for cls in range(len(included_data[subject - 1])):
      for ictal in range(len(included_data[subject - 1][cls])):
        ictal_length = included_data[subject-1][cls][ictal][2] - included_data[subject-1][cls][ictal][1]
        assert (ictal_length) >= period
        epoch_count += min(segment_max,ictal_length//period)
        #epoch_count += segment_max


  #print(f'Number of epochs = {epoch_count}')
  # epochs, samples, channels,bands
  data_x = np.empty((epoch_count,period*sampling_freq,len(selected_ch_names), len(Bands) if Bands else 1),dtype=Data_type)
  data_y = -1*np.ones(epoch_count,dtype=np.uint16)

  #print_prefix = '\n'

  data_count = 0
  subject_count = 0
  data_subject_index = np.zeros((len(Subjects),2)).astype(np.int32) # starting data index for each subject and its number
  data_subject_index[:,1] = Subjects



  #bands_data = None

  for subject in Subjects:

    print(f'Loading subject {subject}/{len(Subjects)}')
    # print(f'\rLoading subject [{subject}], Total subjects [{len(Subjects)}]', end = '')
    #print_prefix = '\n'

    data_subject_index[subject_count,0] = data_count
    subject_count+=1
    skipped_files=[]
    class_count_0 = 0 # number of imported segments for class 0
    for cls in range(len(included_data[subject - 1])): # assuming ictal, preictal, and interictal lists have the same sizes
      class_count_others = 0 # number of imported segments for other classes
      last_file = ""
      for ictal in range(len(included_data[subject - 1][cls])):  # clases: 0 -> ictal, 1 -> preictal
        file_name = f'{data_path}chb{subject:02d}/{included_data[subject-1][cls][ictal][0]}'
        if file_name in skipped_files:
          continue
        if file_name != last_file:
          try:
            raw = read_raw(file_name, selected_ch_names)
            raw.load_data(verbose=False) # needed for filteration
            if resample_freq is not None:
              raw.resample(resample_freq, npad="auto")
            if notch_freqs is not None:
              raw.notch_filter(notch_freqs)

            if Bands is not None:
              # Getting epochs for frequncy bands
              for band, (fmin, fmax) in enumerate(Bands):
                raw_data = raw.copy().filter(fmin, fmax, fir_design='firwin',verbose=False).get_data()
                SZ = raw_data.shape
                if band == 0:
                  bands_data = np.empty((SZ[1],SZ[0],len(Bands)))
                  # Swapping dimensions from (channel, sample) to (sample, channel)
                  bands_data[:,:,band] = raw_data.transpose(1,0)
                else:
                  bands_data[:,:,band] = raw_data.transpose(1,0)
            else:
              raw_data = raw.get_data()
              SZ = raw_data.shape
              # Swapping dimensions from (channel, sample) to (sample, channel)
              bands_data = raw_data.transpose(1,0).reshape(SZ[1],SZ[0],1)
          except Exception as e:
            print ("\n"+ f'Skipping [{file_name.split("/")[-1]}]  {e}')
            skipped_files.append(file_name)
            continue

        #getting data
        ictal_length = included_data[subject-1][cls][ictal][2] - included_data[subject-1][cls][ictal][1]
        for i in range(0,min((ictal_length//period)*period,segment_max*period), period):
          if cls == 0:
            class_count_0 += 1
          else:
            class_count_others +=1
          if class_count_others > class_count_0: break
          # maintaining the same number of segments as in class 0
          start = int((included_data[subject - 1][cls][ictal][1] + i)*sampling_freq)
          end = start + int(period*sampling_freq)
          data_x[data_count,:,:,:] = bands_data[start:end]
          data_y[data_count] = cls
          data_count+=1
        if class_count_others > class_count_0: break
        last_file = file_name

  data_x = data_x[0:data_count]
  data_y = data_y[0:data_count]

  return data_x, data_y, data_subject_index

########################### Function End ####################################

############################ Function Start #################################
def get_data_mitbih(beat_classes, beat_samples=700, Records=None, channels=[0, 1], Data_type=np.float32):
  import wfdb

  dataset_folder = f'{this.CONTENT_FOLDER}/MIT_BIH/mit-bih-arrhythmia-database-1.0.0'

  if Records is None:
    Records = [
      '100','101','102','103','104','105','106','107','108','109',
      '111','112','113','114','115','116','117','118','119','121',
      '122','123','124','200','201','202','203','205','207','208',
      '209','210','212','213','214','215','217','219','220','221',
      '222','223','228','230','231','232','233','234'
    ]

  # Build dictionary: annotation symbol → class index
  ann_to_class = {}
  for i, group in enumerate(beat_classes):
    for symbol in group:
      ann_to_class[symbol] = i

  # Centralizing the window around the R-peak
  # For 700 samples, half_win is 350.
  half_win = beat_samples // 2

  all_x = []
  all_y = []
  data_subject_index = []
  current_total_samples = 0

  for record_name in Records:
    # Record 202 is from the same subject as 201; excluding for inter-patient purity
    if record_name == '202':
      continue

    print(f'\rLoading MIT-BIH record: {record_name}', end="")

    # Read the first channel (MLII usually)
    try:
      record_path = f'{dataset_folder}/{record_name}'

      #signal = wfdb.rdrecord(record_path).p_signal[:, 0]
      signal = wfdb.rdrecord(record_path).p_signal[:, channels]

      ann = wfdb.rdann(record_path, 'atr')
    except Exception as e:
      print(f"\nError loading {record_name}: {e}")
      continue

    x_list, y_list = [], []

    # Iterate through annotations
    for idx, sym in zip(ann.sample, ann.symbol):
      # Skip if symbol is not in our target classes (e.g., skip rhythm changes '+')
      if sym not in ann_to_class:
        continue

      # Define the window boundaries centered on 'idx'
      start = idx - half_win
      end = idx + half_win

      # Ensure the window is entirely within the 30-minute signal

      #if start >= 0 and end < len(signal):
      if start >= 0 and end <= signal.shape[0]:

        #beat = signal[start:end]
        beat = signal[start:end, :]


        # Reshape to (time, channel, band) for your 4D architecture
        # Note: We assume 1 channel and 1 band initially before your filtering

        #x_list.append(beat.reshape(beat_samples, 1, 1))
        x_list.append(beat.reshape(beat_samples, len(channels), 1))

        y_list.append(ann_to_class[sym])

    if len(x_list) > 0:
      # Track the start index and record ID for Inter-Patient splitting later
      data_subject_index.append([current_total_samples, int(record_name)])

      all_x.append(np.stack(x_list, axis=0).astype(Data_type))
      all_y.append(np.array(y_list).astype(np.uint16))

      current_total_samples += len(x_list)

  print("\nFinalizing data arrays...")
  # Concatenate all records into final numpy arrays
  data_x = np.concatenate(all_x, axis=0)
  data_y = np.concatenate(all_y, axis=0)
  data_subject_index = np.array(data_subject_index).astype(np.int32)

  return data_x, data_y, data_subject_index
########################### Function End ####################################

########################### Function Start #################################
def get_data_incart(beat_classes, beat_samples=771, Records=None, channels=[1], Data_type=np.float32):
  import wfdb
  import numpy as np
  import re
  from collections import defaultdict

  dataset_folder = f'{this.CONTENT_FOLDER}/INCART/files'

  if Records is None:
    Records = [f'I{i:02d}' for i in range(1, 76)]

  ann_to_class = {symbol: i for i, group in enumerate(beat_classes) for symbol in group}

  subject_data = defaultdict(lambda: {'x': [], 'y': []})
  half_win = beat_samples // 2

  for record_name in Records:
    print(f'\rProcessing INCART record: {record_name}', end="")

    try:
      record_path = f'{dataset_folder}/{record_name}'
      record_obj = wfdb.rdrecord(record_path)

      # FIX 1: Flexible Subject ID extraction
      subject_id = -1
      for comment in record_obj.comments:
        if 'patient' in comment.lower():
          match = re.search(r'\d+', comment)
          if match:
            subject_id = int(match.group())
            break

      # If no patient ID found in comments, use record number (e.g. I01 -> 1)
      if subject_id == -1:
        match_num = re.search(r'\d+', record_name)
        subject_id = int(match_num.group()) if match_num else record_name

      #signal = record_obj.p_signal[:, 0]
      #signal = record_obj.p_signal[:, 1] # changed from 0 to 1, it supposed to give better results
      signal = record_obj.p_signal[:, channels]

      ann = wfdb.rdann(record_path, 'atr')

      for idx, sym in zip(ann.sample, ann.symbol):
        if sym in ann_to_class:
          # FIX 2: Boundary checks for the larger 3-second window
          start, end = idx - half_win, idx + (beat_samples - half_win)

          #if start >= 0 and end <= len(signal):
          if start >= 0 and end <= signal.shape[0]:

            #beat = signal[start:end]
            beat = signal[start:end, :]

            # Ensure exact sample count to prevent stacking errors
            if len(beat) == beat_samples:
              #subject_data[subject_id]['x'].append(beat.reshape(beat_samples, 1, 1))
              subject_data[subject_id]['x'].append(beat.reshape(beat_samples, len(channels), 1))

              subject_data[subject_id]['y'].append(ann_to_class[sym])

    except Exception as e:
      # Silently skip failed records to keep progress bar clean
      continue

  # Check if we actually found anything
  if not subject_data:
    print(f"\n[!] No beats were matched. Symbols searched: {list(ann_to_class.keys())}")
    return np.array([]), np.array([]), np.array([])

  # Now flatten the dictionary into the final arrays
  all_x, all_y, subject_indices = [], [], []
  current_offset = 0

  for s_id in sorted(subject_data.keys()):
    if not subject_data[s_id]['x']: continue

    beats_x = np.stack(subject_data[s_id]['x'], axis=0).astype(Data_type)
    beats_y = np.array(subject_data[s_id]['y']).astype(np.uint16)

    all_x.append(beats_x)
    all_y.append(beats_y)

    # Convert subject ID to int if possible for the index array
    numeric_id = int(s_id) if str(s_id).isdigit() else 0
    subject_indices.append([current_offset, numeric_id])
    current_offset += len(beats_x)

  print("\nFinalizing arrays...")
  data_x = np.concatenate(all_x, axis=0)
  data_y = np.concatenate(all_y, axis=0)
  data_subject_index = np.array(subject_indices).astype(np.int32)

  return data_x, data_y, data_subject_index
########################### Function End ####################################

########################### Function End ####################################
def get_data_ptbxl(beat_classes, beat_samples=1500, channels=[1], Data_type=np.float32):
  import wfdb
  from wfdb import processing
  import pandas as pd
  import numpy as np
  import ast
  import os

  base_path = f'{this.CONTENT_FOLDER}/PTB_XL/ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3'

  # 1. Load metadata
  df = pd.read_csv(f'{base_path}/ptbxl_database.csv', index_col='ecg_id')
  df.scp_codes = df.scp_codes.apply(lambda x: ast.literal_eval(x))

  # 2. Map classes
  ptb_to_idx = {}
  for i, group in enumerate(beat_classes):
    for code in group:
      ptb_to_idx[code] = i

  # Sort by patient_id to ensure inter-patient split integrity
  df = df.sort_values('patient_id')

  total_beats_accumulated = 0
  half_win = beat_samples // 2

  all_x = []
  all_y = []
  subject_index_list = []

  grouped = df.groupby('patient_id')
  total_patients = len(grouped)

  for i, (patient_id, patient_df) in enumerate(grouped):
    patient_x_list = []
    patient_y_list = []

    print(f'\rProcessing Patient {i+1}/{total_patients} (ID: {int(patient_id)})', end="")

    for ecg_id, row in patient_df.iterrows():
      # Identify class from SCP codes
      label = None
      for scp_code in row.scp_codes.keys():
        if scp_code in ptb_to_idx:
          label = ptb_to_idx[scp_code]
          break

      if label is None:
        continue

      # Using filename_hr (High Resolution - 500Hz)
      record_path = os.path.join(base_path, row.filename_hr)
      try:

        # Load Lead II (index 1)
        #signal_data, fields = wfdb.rdsamp(record_path, channels=[1])
        #signal = signal_data[:, 0]

        # Load ONLY the requested channels from disk
        signal_data, fields = wfdb.rdsamp(record_path, channels=channels)

        # 2. Use the first channel out of your selected list strictly for R-peak detection
        r_peak_detection_signal = signal_data[:, 0]

        fs = fields['fs'] # Should be 500

        # Detect R-peaks for event-based windowing (Overlapping)
        #qrs_inds = processing.xqrs_detect(sig=signal, fs=fs, verbose=False)
        qrs_inds = processing.xqrs_detect(sig=r_peak_detection_signal, fs=fs, verbose=False)


        for idx in qrs_inds:
          # Center the 3-second window on the detected R-peak
          start = idx - half_win
          end = idx + (beat_samples - half_win)

          # Boundary check for the large 1500-sample window
          #if start >= 0 and end <= len(signal):
            #beat = signal[start:end]
          if start >= 0 and end <= signal_data.shape[0]:
            beat = signal_data[start:end, :]  # Slices across time, preserves all selected channels
            if len(beat) == beat_samples:
              # Reshape to (time, channel, band) for your 4D architecture
              #patient_x_list.append(beat.reshape(beat_samples, 1, 1))
              patient_x_list.append(beat.reshape(beat_samples, len(channels), 1))
              #patient_x_list.append(beat.reshape((beat_samples, len(channels), 1)))

              patient_y_list.append(label)
      except Exception:
        continue

    if patient_x_list:
      subject_index_list.append([total_beats_accumulated, int(patient_id)])
      all_x.append(np.stack(patient_x_list, axis=0).astype(Data_type))
      all_y.append(np.array(patient_y_list).astype(np.uint16))
      total_beats_accumulated += len(patient_x_list)

  if not all_x:
    print("\n[!] No PTB-XL beats matched. Check your beat_classes vs SCP codes.")
    return np.array([]), np.array([]), np.array([])

  print("\nFinalizing PTB-XL arrays...")
  data_x = np.concatenate(all_x, axis=0)
  data_y = np.concatenate(all_y, axis=0)
  data_subject_index = np.array(subject_index_list).astype(np.int32)

  return data_x, data_y, data_subject_index
############################ Function End #################################

############################ Function Start #################################
def get_data_bcicomptIV2a(Subjects = np.arange(1,19), Exclude=None, data_path=None,Bands=None, resample_freq=None, Data_type=np.float32, tmin=0, tmax=4,Baseline=None, notch_freqs=None):

  if data_path is None:
    data_path=f'{this.CONTENT_FOLDER}/bcicomptIV2a/'

  # First subject in Subjects and Exclude has number = 1

  if Exclude is not None:
    print('Excluded Subjects are '+ str(Exclude))
    Subjects = np.delete(Subjects,np.isin(Subjects,Exclude))
  else:
    print('No subject excluded')

  subject_count = 0
  data_subject_index = np.zeros((len(Subjects),2)).astype(np.int32) # starting data index for each subject and its number
  data_subject_index[:,1] = Subjects
  data_count = 0
  for sub_index,subject in enumerate(Subjects):
    #print(f'\rLoading subject {sub_index+1}/{len(Subjects)}', end = '')
    print(f'\rLoading subject [{sub_index+1}], Total subjects [{len(Subjects)}]', end = '')
    data_subject_index[subject_count,0] = data_count
    subject_count+=1

    if subject in range(1,10):
      dataset_type = 'T'
      sub =subject
      event_dict = {'769':1, '770':2, '771':3, '772':4}
    else:
      dataset_type = 'E'
      sub =subject - 9
      event_dict= {'783':1}

    file_name = f'{data_path}A{sub:02d}{dataset_type}.gdf'
    raw = mne.io.read_raw_gdf(file_name,verbose='ERROR')
    raw.load_data(verbose=False) # needed for filteration
    if resample_freq is not None:
      raw.resample(resample_freq, npad="auto")

    if notch_freqs is not None:
      raw.notch_filter(notch_freqs)

    events, _ = mne.events_from_annotations(raw,event_id = event_dict, verbose=False)
    picks = mne.pick_channels_regexp(raw.ch_names, regexp=r'EEG*')
    if Bands is not None:
      # Getting epochs for different frequncy bands   
      for band, (fmin, fmax) in enumerate(Bands):
        raw_bandpass = raw.copy().filter(fmin, fmax, fir_design='firwin',verbose=False)
        epochs = mne.Epochs(raw_bandpass, events, event_id=event_dict,baseline=Baseline, tmin=tmin, tmax=tmax, preload=True, picks=picks, event_repeated = 'drop',verbose=False)
        if not 'bands_data' in locals():
          D_SZ = epochs.get_data(copy=False).shape
          bands_data = np.empty((D_SZ[0],D_SZ[2],D_SZ[1],len(Bands)))
        # Swapping dimensions from (epoch, channel, sample) to (epoch, sample, channel)
        bands_data[:,:,:,band] = epochs.get_data(copy=True).transpose(0,2,1) 
        del raw_bandpass
    else:
      epochs = mne.Epochs(raw, events, event_id=event_dict,baseline=Baseline, tmin=tmin, tmax=tmax, preload=True, picks=picks, event_repeated = 'drop',verbose=False)
      bands_data = epochs.get_data(copy=True)
      SZ = bands_data.shape
      # Swapping dimensions from (epoch, channel, sample) to (epoch, sample, channel)
      bands_data = bands_data.transpose(0,2,1).reshape(SZ[0],SZ[2],SZ[1],1)
    
    # reading event type from .mat files 
    mat_vals = scipy.io.loadmat(f'{data_path}A{sub:02d}{dataset_type}.mat')
    tmp_y = mat_vals['classlabel'].flatten()


    # Adjusting events numbers to be compatible with output classes numbers
    tmp_y = tmp_y - 1

    max_epochs = 288
    SZ = bands_data.shape      
    # Creating output x and y matrices
    if not 'data_x' in locals():
      data_x = np.empty((max_epochs*len(Subjects),SZ[1],SZ[2],SZ[3]),dtype=Data_type)
      data_y = np.empty(max_epochs*len(Subjects),dtype=np.uint16)

    ## adjusting data type
    bands_data = bands_data.astype(Data_type)
    tmp_y = tmp_y.astype(np.uint16)

  
    data_x[data_count:data_count + SZ[0],:,:,:] = bands_data
    data_y[data_count:data_count + SZ[0]] = tmp_y
      
    data_count+=SZ[0]

    del raw, epochs, tmp_y, bands_data # saving memory 

  # data_x = data_x[0:data_count,:,:,:]
  # data_y = data_y[0:data_count]


  return data_x, data_y, data_subject_index

########################### Function End ####################################


############################ Function Start #################################
def get_data_physionet(Subjects=np.arange(1,110), Exclude=np.array([88,89,92,100,104]), data_path=None,Bands=None, resample_freq=None, Total=100, Data_type=np.float32, tmin=0, tmax=2,Tasks=np.array([[3,7,11],[5,9,13]]),  Baseline=None, notch_freqs=None):


  if data_path is None:
    data_path=f'{this.CONTENT_FOLDER}/physionet/'

  # First subject in Subjects and Exclude has number = 1

  if Exclude is not None:
    print('Excluded Subjects are '+ str(Exclude))
    Subjects = np.delete(Subjects,np.isin(Subjects,Exclude))
  else:
    print('No subject excluded')

  subject_count = 0
  data_subject_index = np.zeros((len(Subjects),2)).astype(np.int32) # starting data index for each subject and its number
  data_subject_index[:,1] = Subjects
  data_count = 0
  for sub_index, subject in enumerate(Subjects):
    #print(f'\rLoading subject {sub_index+1}/{len(Subjects)}', end = '')
    print(f'\rLoading subject [{sub_index+1}], Total subjects [{len(Subjects)}]', end = '')
    data_subject_index[subject_count,0] = data_count
    subject_count+=1
    for run in Tasks.flatten():
      file_name = f'{data_path}/files/S{subject:03d}/S{subject:03d}R{run:02d}.edf'
      raw = mne.io.read_raw_edf(file_name,verbose=False)
      raw.load_data(verbose=False) # needed for filteration
      if resample_freq is not None:
        raw.resample(resample_freq, npad="auto")
      if notch_freqs is not None:
        raw.notch_filter(notch_freqs)
      events, event_dict = mne.events_from_annotations(raw,verbose=False)
      if Bands is not None:
        # Getting epochs for different frequncy bands   
        for band, (fmin, fmax) in enumerate(Bands):
          raw_bandpass = raw.copy().filter(fmin, fmax, fir_design='firwin',verbose=False)
          epochs = mne.Epochs(raw_bandpass, events, event_id=event_dict,baseline=Baseline, tmin=tmin, tmax=tmax, preload=True, event_repeated = 'drop',verbose=False)
          if not 'bands_data' in locals():
            D_SZ = epochs.get_data(copy=False).shape
            bands_data = np.empty((D_SZ[0],D_SZ[2],D_SZ[1],len(Bands)))
          # Swapping dimensions from (epoch, channel, sample) to (epoch, sample, channel)
          bands_data[:,:,:,band] = epochs.get_data(copy=True).transpose(0,2,1) 
          del raw_bandpass
      else:
        epochs = mne.Epochs(raw, events, event_id=event_dict,baseline=Baseline, tmin=tmin, tmax=tmax, preload=True, event_repeated = 'drop',verbose=False)
        bands_data = epochs.get_data(copy=True)
        SZ = bands_data.shape
        # Swapping dimensions from (epoch, channel, sample) to (epoch, sample, channel)
        bands_data = bands_data.transpose(0,2,1).reshape(SZ[0],SZ[2],SZ[1],1)
      tmp_y = epochs.events[:,2]

      # Adjusting events numbers to be compatible with output classes numbers
      if run in Tasks[0]:
        tmp_y = tmp_y - 1
      elif run in Tasks[1]:
        tmp_y = tmp_y - 1
        tmp_y[tmp_y==1]=3
        tmp_y[tmp_y==2]=4

      SZ = bands_data.shape

      # Creating output x matrix
      if not 'data_x' in locals():
        file_count = 6
        max_epochs = 30
        data_x = np.empty((max_epochs*len(Subjects)*file_count,SZ[1],SZ[2],SZ[3]),dtype=Data_type)
        data_y = np.empty((max_epochs*len(Subjects)*file_count),dtype=np.uint16)

      ## adjusting data type
      bands_data = bands_data.astype(Data_type)
      tmp_y = tmp_y.astype(np.uint16)


      data_x[data_count:data_count + SZ[0],:,:,:] = bands_data
      data_y[data_count:data_count + SZ[0]] = tmp_y
      data_count+=SZ[0]
      del raw, epochs, tmp_y, bands_data # saving memory 
      
      

  data_x = data_x[0:data_count,:,:,:]
  data_y = data_y[0:data_count]

  # removing samples with odd output
  min_cat = 0
  max_cat = 4

  idx = np.flatnonzero(np.logical_or(data_y > max_cat,data_y < min_cat))
  data_x = np.delete(data_x,idx, axis=0)
  data_y = np.delete(data_y,idx)
  del idx

  return data_x, data_y, data_subject_index

########################### Function End ####################################

########################### Function Start ##################################
def get_pos_map(dataset):
  if dataset=='bcicomptIV2a':
    pos_map = np.array([
      [-1,-1,-1, 1,-1,-1,-1], 
      [-1, 2, 3, 4, 5, 6,-1], 
      [ 7, 8, 9,10,11,12,13], 
      [-1,14,15,16,17,18,-1], 
      [-1,-1,19,20,21,-1,-1], 
      [-1,-1,-1,22,-1,-1,-1]])
  elif dataset=='physionet':
    pos_map = np.array([
      [-1,-1,-1,-1,22,23,24,-1,-1,-1,-1],
      [-1,-1,-1,25,26,27,28,29,-1,-1,-1], 
      [-1,30,31,32,33,34,35,36,37,38,-1], 
      [-1,39, 1, 2, 3, 4, 5, 6, 7,40,-1], 
      [43,41, 8, 9,10,11,12,13,14,42,44], 
      [-1,45,15,16,17,18,19,20,21,46,-1], 
      [-1,47,48,49,50,51,52,53,54,55,-1], 
      [-1,-1,-1,56,57,58,59,60,-1,-1,-1], 
      [-1,-1,-1,-1,61,62,63,-1,-1,-1,-1],
      [-1,-1,-1,-1,-1,64,-1,-1,-1,-1,-1]])
  elif dataset=='ttk':
    pos_map = np.array([
      [-1,-1,-1,-1, 1,-1,31,-1,-1,-1,-1],
      [-1,-1,-1,32,33,34,61,60,-1,-1,-1],
      [-1, 4,36, 3,35, 2,62,29,59,30,-1],
      [ 5,37, 6,38, 7,63,28,57,27,58,26],
      [-1, 9,40, 8,39,-1,56,24,55,25,-1],
      [10,41,11,42,12,52,23,53,22,54,21],
      [-1,15,44,14,43,13,51,19,50,20,-1],
      [-1,-1,-1,45,46,47,48,49,-1,-1,-1],
      [-1,-1,-1,-1,16,17,18,-1,-1,-1,-1]])
  elif dataset=='chbmit':
    raise Exception("Position matrix not yet implemented for Chbmit dataset")
  else:
    sys.exit("Position map not defined for this dataset.")
  return pos_map
########################### Function End  ###################################

########################### Function Start ##################################

def make_into_2d(data_1d,pos_map):
  Map = pos_map
  map_sz = Map.shape
  SZ = data_1d.shape # (epochs, time samples, eeg channels, bands)
  Map = Map.flatten()
  idx = np.arange(Map.shape[0])
  idx = idx[Map > 0]
  Map = Map[Map > 0]
  Map = Map -1 # adjusting index to start from 0
  data_2d = np.zeros((SZ[0],SZ[1], map_sz[0]*map_sz[1], SZ[3]),dtype=data_1d.dtype)
  
  data_2d[:,:,idx,:] = data_1d[:,:,Map,:]
  data_2d = data_2d.reshape(SZ[0],SZ[1], map_sz[0],map_sz[1], SZ[3])
  return data_2d
########################### Function End ####################################


############################ Function Start #################################
def download_dataset(dataset):
  if dataset=='physionet':
    dataset_folder=f'{this.DATA_FOLDER}/datasets'
    os.makedirs(dataset_folder, exist_ok=True)

    zipfile_list = [f'{this.DATA_FOLDER}/datasets/eeg-motor-movementimagery-dataset-1.0.0.zip']
    zipfile_url_list = ['https://physionet.org/static/published-projects/eegmmidb/eeg-motor-movementimagery-dataset-1.0.0.zip']

    output_path = f'{this.CONTENT_FOLDER}/physionet/'
    
  elif dataset=='bcicomptIV2a':
    dataset_folder=f'{this.DATA_FOLDER}/datasets'
    os.makedirs(dataset_folder, exist_ok=True)

    zipfile_list = [f'{this.DATA_FOLDER}/datasets/BCICIV_2a_gdf.zip', f'{this.DATA_FOLDER}/datasets/true_labels.zip']
    zipfile_url_list = ['https://www.bbci.de/competition/download/competition_iv/BCICIV_2a_gdf.zip', 'https://www.bbci.de/competition/iv/results/ds2a/true_labels.zip']
    output_path = f'{this.CONTENT_FOLDER}/bcicomptIV2a/'
  elif dataset=='ttk':
    print(f'This dataset is private, download is not available')
    return
  elif dataset=='chbmit':
    print(f'Skipping download. Data files are downloaded automatically as needed.')
    return
  elif dataset=='mitbih':

    dataset_folder=f'{this.DATA_FOLDER}/datasets'
    os.makedirs(dataset_folder, exist_ok=True)

    zipfile_list = [f'{this.DATA_FOLDER}/datasets/mit-bih-arrhythmia-database-1.0.0.zip']
    zipfile_url_list = ['https://physionet.org/static/published-projects/mitdb/mit-bih-arrhythmia-database-1.0.0.zip']
    output_path = f'{this.CONTENT_FOLDER}/MIT_BIH/'

  elif dataset=='incart':

    dataset_folder=f'{this.DATA_FOLDER}/datasets'
    os.makedirs(dataset_folder, exist_ok=True)

    zipfile_list = [f'{this.DATA_FOLDER}/datasets/st-petersburg-incart-12-lead-arrhythmia-database-1.0.0.zip']
    zipfile_url_list = ['https://physionet.org/static/published-projects/incartdb/st-petersburg-incart-12-lead-arrhythmia-database-1.0.0.zip']
    output_path = f'{this.CONTENT_FOLDER}/INCART/'

  elif dataset=='ptbxl':

    dataset_folder=f'{this.DATA_FOLDER}/datasets'
    os.makedirs(dataset_folder, exist_ok=True)

    zipfile_list = [f'{this.DATA_FOLDER}/datasets/ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3.zip']
    zipfile_url_list = ['https://physionet.org/static/published-projects/ptb-xl/ptb-xl-a-large-publicly-available-electrocardiography-dataset-1.0.3.zip']
    output_path = f'{this.CONTENT_FOLDER}/PTB_XL/'

  else:
    raise Exception("Unknown dataset")

  if os.path.exists(output_path) and len(os.listdir(output_path)) > 0:
    print('Data already exists.')
    return

  for zipfile,url in zip(zipfile_list,zipfile_url_list):
    get_ipython().system(f'wget -c -q --show-progress {url} -P {dataset_folder}')

  
  print ('Unzipping data.')
  for zipfile in zipfile_list:
    get_ipython().system('unzip -qq ' + zipfile +' -d ' + output_path)
  print ('Unzipping done.')  
  return
########################### Function End ####################################


########################### Function Start ##################################
def balance(data_x, data_y, data_subject_index,class_max):
  # make number of segments for each subject equal to the minimum per class
  # if align_to_minimum it true then all subjects have the same number of classes

  data_subject_index = np.copy(data_subject_index)
  sub_num = len(data_subject_index)

  Classes, counts = (),()
  for sub_index in range(sub_num):
    start=data_subject_index[sub_index,0]
    if sub_index < (sub_num - 1):
      end = data_subject_index[sub_index+1,0]
    else:
      end = len(data_y)
    val, cnt = np.unique(data_y[start:end], return_counts=True)
    Classes=(*Classes,val)
    counts = (*counts,cnt)

  for sub_index in range(sub_num):
    start = data_subject_index[sub_index,0]
    if sub_index < (sub_num - 1):
      end = data_subject_index[sub_index+1,0]
    else:
      end = len(data_y)
    for class_index in range(len(Classes[sub_index])):
      clc = Classes[sub_index][class_index]
      if clc not in class_max: continue
      diff = counts[sub_index][class_index] - class_max[clc]
      if diff>0:
        index = np.flatnonzero(data_y[start:end]==clc)
        index += start
        data_x = np.delete(data_x,index[:diff],axis=0)
        data_y = np.delete(data_y,index[:diff],axis=0)
        if sub_index < sub_num - 1:
          data_subject_index[sub_index+1:,0] -=  diff

  print ('Balancing data done.')

  return data_x, data_y, data_subject_index
############################ Function End ###################################


############################ Function Start #################################
def normalize(data_x, level='array'):
  if level == 'array': # this gives the best results

    mean = data_x.mean()
    std  = data_x.std()

    # avoid division by zero
    if std == 0: std = 1

    data_x = (data_x - mean) / std

  elif level == 'band':
    # normalize each band independently
    axes = tuple(range(data_x.ndim - 1))

    mean = data_x.mean(axis=axes, keepdims=True)
    std  = data_x.std(axis=axes, keepdims=True)

    # avoid division by zero
    std[std == 0] = 1

    data_x = (data_x - mean) / std

  elif level == 'time_series': # this gives bad results
    # normalize each time series independently
    mean = data_x.mean(axis=1, keepdims=True)
    std  = data_x.std(axis=1, keepdims=True)

    # avoid division by zero
    std[std == 0] = 1

    data_x = (data_x - mean) / std

  else:
    raise ValueError("Unrecognized normalization level")

  print(f'Normalizing data done. ({level} level) ')
  return data_x
############################ Function End ###################################


############################ Function Start #################################
def video_array(data_x, data_y, Class=0, Band=0,Rows=4, Cols=5, Seed=100):

  import matplotlib.pyplot as plt
  import matplotlib.animation as animation
  from IPython.display import HTML

  fig = plt.figure()
  ims = []
  index = np.flatnonzero(data_y == Class)
  np.random.seed(Seed)
  np.random.shuffle(index)
  index = index[:Rows*Cols]
  print('samples = ' +str(index))
  total_frames = data_x.shape[1]
  for frame in range(total_frames):
    img_count = 0
    img = data_x[index[img_count],frame,:,:,Band]
    img_count+=1
    for col in range(1,Cols):
      img = np.append(img,data_x[index[img_count],frame,:,:,Band],axis=1)
      img_count+=1
    for row in range(1,Rows):
      img_col = data_x[index[img_count],frame,:,:,Band]
      img_count+=1
      for col in range(1,Cols):
        img_col = np.append(img_col,data_x[index[img_count],frame,:,:,Band],axis=1)
        img_count+=1
      img = np.append(img,img_col,axis=0)

    im = plt.imshow(img, animated=True)
    plt.clim(-2, 2)  
    ims.append([im])

  plt.colorbar()
  plt.xticks([])
  plt.yticks([])
  plt.close()
  ani = animation.ArtistAnimation(fig, ims, interval=500, blit=True, repeat_delay=1000)
  display(HTML(ani.to_html5_video()))
  return
############################# Function End ##################################

############################ Function Start #################################
def select_classes(data_x, data_y, data_subject_index, selected_classes):
  selected_index = np.isin(data_y,selected_classes)
  data_y_out = data_y[selected_index]
  data_x_out = data_x[selected_index]
  data_subject_index_out = data_subject_index.copy()
  for subject in range(1,len(data_subject_index)):
    start=data_subject_index[subject-1,0]
    end=data_subject_index[subject,0]
    data_subject_index_out[subject:,0] = data_subject_index_out[subject:,0] - np.count_nonzero(~selected_index[start:end])

  return data_x_out, data_y_out, data_subject_index_out
############################ Function End ###################################

############################ Function Start #################################
def select_subjects(data_x, data_y, data_subject_index, selected_subjects):

  # Check if all elements in selected_subjects exist in data_subject_index[:,1]
  if not np.isin(selected_subjects, data_subject_index[:, 1]).all():
      raise Exception("Some entries in selected_subjects are not in data_subject_index")

  data_subject_index_out = data_subject_index.copy()
  selected_data_indices = np.ones(len(data_x), dtype=bool)

  subjects = data_subject_index[:, 1]
  selected_sub_indices = np.isin(subjects, selected_subjects)

  total_subjects = len(subjects)

  # deselecting data
  for subject in range(total_subjects):
    if not selected_sub_indices[subject]:
      start = int(data_subject_index[subject, 0])
      if subject == total_subjects - 1:
          end = len(data_x)
      else:
          end = int(data_subject_index[subject + 1, 0])
      data_subject_index_out[subject:, 0] -= (end - start)
      selected_data_indices[start:end] = False

  data_x_out = data_x[selected_data_indices]
  data_y_out = data_y[selected_data_indices]
  data_subject_index_out = data_subject_index_out[selected_sub_indices]

  return data_x_out, data_y_out, data_subject_index_out
############################ Function End ###################################

############################ Function Start #################################
def shuffle_subjects(data_x,data_y,data_subject_index,INFO):

  data_subject_index = data_subject_index.copy()

  data_length = np.append(data_subject_index[1:,0],data_x.shape[0])  - data_subject_index[:,0]


  np.random.seed(INFO['shuffle_seed'])
  np.random.shuffle(data_length)

  np.random.seed(INFO['shuffle_seed'])
  np.random.shuffle(data_subject_index)

  data_x_out = np.zeros(data_x.shape)
  data_y_out = np.zeros(data_y.shape)

  start_out = 0
  for c  in range(len(data_subject_index)):
    end_out = start_out + data_length[c]
    start_in = data_subject_index[c,0]
    end_in = start_in + data_length[c]
    data_x_out[start_out:end_out] = data_x[start_in:end_in]
    data_y_out[start_out:end_out] = data_y[start_in:end_in]

    data_subject_index[c,0] = start_out
    start_out = end_out
  
  return data_x, data_y, data_subject_index
############################ Function End ###################################

############################ Function Start #################################
def build_model(data_x, data_yc, model_type,INFO):

  if isinstance(data_x,list):
    input_list_SZ = len(data_x)
    data_x = data_x[0]
  else:
    input_list_SZ = 1

    
  SZ = data_x.shape

  if len(SZ)== 4:
    x_dim = SZ[2]
    y_dim = 1
    n_bands = SZ[3]
  elif len(SZ)==5:
    x_dim = SZ[2]
    y_dim = SZ[3]
    n_bands = SZ[4]

  n_timesteps, n_outputs = SZ[1], data_yc.shape[1]

  # update metrics
  set_metrics(n_outputs=n_outputs)


  if model_type=='EEGNet':
    nb_classes = n_outputs
    Chans=x_dim*y_dim
    Samples=n_timesteps
    dropoutRate=0.5
    kernLength=64
    F1=8
    D=2
    F2=16
    dropoutType=Dropout
    #dropoutType=SpatialDropout2D # another option for dropout
    norm_rate=.25
    input_shape = (Samples, Chans, n_bands)
    conv_filters = (kernLength, 1)
    depth_filters = (1, Chans)
    pool_size = (6, 1)
    pool_size2 = (12, 1)
    separable_filters = (20, 1)
    axis = -1

    input1 = Input(shape=input_shape)
    block1 = Conv2D(F1, conv_filters, padding='same', input_shape=input_shape,use_bias=False)(input1)
    if INFO['batch_norm']: block1 = BatchNormalization(axis=axis)(block1)
    block1 = DepthwiseConv2D(depth_filters, use_bias=False, depth_multiplier=D, depthwise_constraint=max_norm(1.))(block1)
    if INFO['batch_norm']: block1 = BatchNormalization(axis=axis)(block1)
    block1 = Activation('elu')(block1)
    block1 = AveragePooling2D(pool_size)(block1)
    block1 = dropoutType(dropoutRate)(block1)

    block2 = SeparableConv2D(F2, separable_filters, use_bias=False, padding='same')(block1)
    if INFO['batch_norm']: block2 = BatchNormalization(axis=axis)(block2)
    block2 = Activation('elu')(block2)
    block2 = AveragePooling2D(pool_size2)(block2)
    block2 = dropoutType(dropoutRate)(block2)

    flatten = Flatten(name='flatten')(block2)

    dense = Dense(nb_classes, name='dense', kernel_constraint=max_norm(norm_rate))(flatten)
    softmax = Activation('softmax', name='softmax')(dense)

    model = Model(inputs=input1, outputs=softmax)
    model.compile(loss=binary_crossentropy, optimizer=Adam(learning_rate=0.001), metrics=this.MODEL_METRICS)
    if INFO['show_summary']:
      model.summary()
    return model


  if model_type=='ShallowConvNet':
    nb_classes = n_outputs
    Chans=x_dim*y_dim
    Samples=n_timesteps
    dropoutRate=0.5
    norm_rate=0.5

    
    input_shape = (Samples, Chans, n_bands)
    conv_filters = (25, 1)
    conv_filters2 = (1, Chans)
    pool_size = (45, 1)
    strides = (15, 1)
    axis = -1


    input_main = Input(input_shape)
    block1 = Conv2D(20, conv_filters, input_shape=input_shape, kernel_constraint=max_norm(2., axis=(0, 1, 2)))(input_main)
    block1 = Conv2D(20, conv_filters2, use_bias=False, kernel_constraint=max_norm(2., axis=(0, 1, 2)))(block1)
    if INFO['batch_norm']: block1 = BatchNormalization(axis=axis, epsilon=1e-05, momentum=0.1)(block1)
    block1 = Activation(square)(block1)
    block1 = AveragePooling2D(pool_size=pool_size, strides=strides)(block1)
    block1 = Activation(log)(block1)
    block1 = Dropout(dropoutRate)(block1)
    flatten = Flatten()(block1)
    dense = Dense(nb_classes, kernel_constraint=max_norm(norm_rate))(flatten)
    softmax = Activation('softmax')(dense)

    model = Model(inputs=input_main, outputs=softmax)
    model.compile(loss=binary_crossentropy, optimizer=Adam(learning_rate=0.001), metrics=this.MODEL_METRICS)
    if INFO['show_summary']:
      model.summary()
    return model

  if model_type=='DeepConvNet':
    nb_classes = n_outputs
    Chans=x_dim*y_dim
    Samples=n_timesteps
    dropoutRate=0.5
    norm_rate=0.5
    input_shape = (Samples, Chans, n_bands)
    conv_filters = (2, 1)
    conv_filters2 = (1, Chans)
    pool = (2, 1)
    strides = (2, 1)
    axis = -1


    # start the model
    input_main = Input(input_shape)
    block1 = Conv2D(25, conv_filters, input_shape=input_shape, kernel_constraint=max_norm(2., axis=(0, 1, 2)))(input_main)
    block1 = Conv2D(25, conv_filters2, kernel_constraint=max_norm(2., axis=(0, 1, 2)))(block1)
    if INFO['batch_norm']: block1 = BatchNormalization(axis=axis, epsilon=1e-05, momentum=0.1)(block1)
    block1 = Activation('elu')(block1)
    block1 = MaxPooling2D(pool_size=pool, strides=strides)(block1)
    block1 = Dropout(dropoutRate)(block1)

    block2 = Conv2D(50, conv_filters, kernel_constraint=max_norm(2., axis=(0, 1, 2)))(block1)
    if INFO['batch_norm']: block2 = BatchNormalization(axis=axis, epsilon=1e-05, momentum=0.1)(block2)
    block2 = Activation('elu')(block2)
    block2 = MaxPooling2D(pool_size=pool, strides=strides)(block2)
    block2 = Dropout(dropoutRate)(block2)

    block3 = Conv2D(100, conv_filters, kernel_constraint=max_norm(2., axis=(0, 1, 2)))(block2)
    if INFO['batch_norm']: block3 = BatchNormalization(axis=axis, epsilon=1e-05, momentum=0.1)(block3)
    block3 = Activation('elu')(block3)
    block3 = MaxPooling2D(pool_size=pool, strides=strides)(block3)
    block3 = Dropout(dropoutRate)(block3)

    block4 = Conv2D(200, conv_filters, kernel_constraint=max_norm(2., axis=(0, 1, 2)))(block3)
    if INFO['batch_norm']: block4 = BatchNormalization(axis=axis, epsilon=1e-05, momentum=0.1)(block4)
    block4 = Activation('elu')(block4)
    block4 = MaxPooling2D(pool_size=pool, strides=strides)(block4)
    block4 = Dropout(dropoutRate)(block4)

    flatten = Flatten()(block4)

    dense = Dense(nb_classes, kernel_constraint=max_norm(norm_rate))(flatten)
    softmax = Activation('softmax')(dense)

    model = Model(inputs=input_main, outputs=softmax)
    model.compile(loss=binary_crossentropy, optimizer=Adam(learning_rate=0.001), metrics=this.MODEL_METRICS)
    if INFO['show_summary']:
      model.summary()
    return model


  if model_type=='EEGNet_fusion':
    """
    The author of this model is Karel Roots and was published along with the paper titled 
    "Fusion Convolutional Neural Network for Cross-Subject EEG Motor Imagery Classification"
    """

    nb_classes = n_outputs
    Chans=x_dim*y_dim
    Samples=n_timesteps
    dropoutRate=0.5
    dropoutType=Dropout
    #dropoutType=SpatialDropout2D # another option for dropout
    norm_rate=0.25
    input_shape = (Samples, Chans, n_bands)
    conv_filters = (64, 1)
    conv_filters2 = (96, 1)
    conv_filters3 = (128, 1)    
    #depth_filters = (1, Chans)
    depth_filters = (n_bands, Chans) # made improvement
    pool_size = (4, 1)
    pool_size2 = (8, 1)
    separable_filters = (8, 1)
    separable_filters2 = (16, 1)
    separable_filters3 = (32, 1)
    axis = -1

    F1 = 8
    F1_2 = 16
    F1_3 = 32
    F2 = 16
    F2_2 = 32
    F2_3 = 64
    D = 2
    D2 = 2
    D3 = 2

    input1 = Input(shape=input_shape)
    block1 = Conv2D(F1, conv_filters, padding='same', input_shape=input_shape, use_bias=False)(input1)
    if INFO['batch_norm']: block1 = BatchNormalization(axis=axis)(block1)
    block1 = DepthwiseConv2D(depth_filters, use_bias=False, depth_multiplier=D, depthwise_constraint=max_norm(1.))(block1)
    if INFO['batch_norm']: block1 = BatchNormalization(axis=axis)(block1)
    block1 = Activation('elu')(block1)
    block1 = AveragePooling2D(pool_size)(block1)
    block1 = dropoutType(dropoutRate)(block1)

    block2 = SeparableConv2D(F2, separable_filters, use_bias=False, padding='same')(block1)  # 8
    if INFO['batch_norm']: block2 = BatchNormalization(axis=axis)(block2)
    block2 = Activation('elu')(block2)
    block2 = AveragePooling2D(pool_size2)(block2)
    block2 = dropoutType(dropoutRate)(block2)
    block2 = Flatten()(block2)  # 13

    # 8 - 13

    input2 = Input(shape=input_shape)
    block3 = Conv2D(F1_2, conv_filters2, padding='same', input_shape=input_shape, use_bias=False)(input2)
    if INFO['batch_norm']: block3 = BatchNormalization(axis=axis)(block3)
    block3 = DepthwiseConv2D(depth_filters, use_bias=False, depth_multiplier=D2, depthwise_constraint=max_norm(1.))(block3)
    if INFO['batch_norm']: block3 = BatchNormalization(axis=axis)(block3)
    block3 = Activation('elu')(block3)
    block3 = AveragePooling2D(pool_size)(block3)
    block3 = dropoutType(dropoutRate)(block3)

    block4 = SeparableConv2D(F2_2, separable_filters2, use_bias=False, padding='same')(block3)  # 22
    if INFO['batch_norm']: block4 = BatchNormalization(axis=axis)(block4)
    block4 = Activation('elu')(block4)
    block4 = AveragePooling2D(pool_size2)(block4)
    block4 = dropoutType(dropoutRate)(block4)
    block4 = Flatten()(block4)  # 27
    # 22 - 27

    input3 = Input(shape=input_shape)
    block5 = Conv2D(F1_3, conv_filters3, padding='same', input_shape=input_shape, use_bias=False)(input3)
    if INFO['batch_norm']: block5 = BatchNormalization(axis=axis)(block5)
    block5 = DepthwiseConv2D(depth_filters, use_bias=False, depth_multiplier=D3, depthwise_constraint=max_norm(1.))(block5)
    if INFO['batch_norm']: block5 = BatchNormalization(axis=axis)(block5)
    block5 = Activation('elu')(block5)
    block5 = AveragePooling2D(pool_size)(block5)
    block5 = dropoutType(dropoutRate)(block5)

    block6 = SeparableConv2D(F2_3, separable_filters3, use_bias=False, padding='same')(block5)  # 36
    if INFO['batch_norm']: block6 = BatchNormalization(axis=axis)(block6)
    block6 = Activation('elu')(block6)
    block6 = AveragePooling2D(pool_size2)(block6)
    block6 = dropoutType(dropoutRate)(block6)
    block6 = Flatten()(block6)  # 41

    # 36 - 41

    merge_one = concatenate([block2, block4])
    merge_two = concatenate([merge_one, block6])

    flatten = Flatten()(merge_two)

    dense = Dense(nb_classes, name='dense', kernel_constraint=max_norm(0.25))(flatten)

    softmax = Activation('softmax', name='softmax')(dense)

    model= Model(inputs=[input1, input2, input3], outputs=softmax)

    model.compile(loss=binary_crossentropy, optimizer=Adam(learning_rate=0.001), metrics=this.MODEL_METRICS)
    if INFO['show_summary']:
      model.summary()
    return model

  if model_type=='CNN1D_MFBF':

    input_set=[]
    block_set=[]
    dropoutRate = INFO['dropout_rate']
    
    for band in range(input_list_SZ):
      input_set.append(Input(shape=(n_timesteps, x_dim*y_dim)))
      #block1 = Lambda(lambda x: x[:,:,:,band])(input_set[band])
      
      block1 = AveragePooling1D(pool_size=(2))(input_set[band])
      block1 = Conv1D(50,5,padding='same')(block1)
      block1 = Activation(INFO['activation_name'])(block1) # try elu instead of relu
      block1 = Dropout(dropoutRate)(block1)
      
      block1 = AveragePooling1D(pool_size=(2))(block1)
      block1 = Conv1D(50,5,padding='same')(block1)
      block1 = Activation(INFO['activation_name'])(block1) # try elu instead of relu
      block1 = Dropout(dropoutRate)(block1)
      
      block1 = AveragePooling1D(pool_size=(2))(block1)
      block1 = Conv1D(50,5,padding='same')(block1)
      block1 = Activation(INFO['activation_name'])(block1) # try elu instead of relu
      block1 = Dropout(dropoutRate)(block1)

      block1 = AveragePooling1D(pool_size=(2))(block1)
      block1 = Dropout(dropoutRate)(block1)
      block_set.append(Flatten()(block1))

    # merging models  
    merge_block  = concatenate(block_set)
    flatten = Flatten()(merge_block)
    dense = Dense(n_outputs, name='dense', kernel_constraint=max_norm(INFO['max_norm']))(flatten)
    softmax = Activation('softmax', name='softmax')(dense)
    
    model= Model(inputs=input_set, outputs=softmax)

    model.compile(loss=binary_crossentropy, optimizer=Adam(learning_rate=0.001), metrics=this.MODEL_METRICS)
    if INFO['show_summary']:
      model.summary()
    return model


  if model_type=='ECG1DA':
    model = Sequential()
    time_axis = -1
    model.add(InputLayer(shape=(n_timesteps, x_dim * y_dim, n_bands)))
    model.add(Reshape((n_timesteps, x_dim*y_dim*n_bands)) )

    for i in range(3):
      model.add(Conv1D (128, 10, activation = 'relu'))
      model.add(Conv1D (128, 10, activation = 'relu'))
      model.add(MaxPooling1D(pool_size=(2)))
      model.add(Dropout(0.2))
      model.add(BatchNormalization())
    model.add(Flatten())
    model.add(Dense(512, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(n_outputs, activation='softmax'))
    model.compile(loss=categorical_crossentropy, optimizer=Adam(learning_rate=0.001), metrics=this.MODEL_METRICS)
    if INFO['show_summary']:
      model.summary()
    return model

  # Adding separate model.add(Activation(activations.relu)) line
  # helps with memeory leak
  # see link: https://github.com/tensorflow/tensorflow/issues/31312

  model = Sequential()
  if model_type=='Basic':
    model.add(InputLayer(shape=(n_timesteps, x_dim * y_dim, n_bands)))
    model.add(Flatten())
  elif model_type=='CNN1D':
    time_axis = -1
    model.add(InputLayer(shape=(n_timesteps, x_dim * y_dim, n_bands)))
    model.add(Reshape((n_timesteps, x_dim*y_dim*n_bands)) )
    # model.add(Permute((2,1), shape=(n_timesteps, x_dim * y_dim * n_bands)))
    model.add(AveragePooling1D(pool_size=(5)))
    model.add(Conv1D(50, 5,  padding='same', activation=None))
    if INFO['batch_norm']: model.add(BatchNormalization())
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(AveragePooling1D(pool_size=(2)))
    model.add(Conv1D(50, 5, padding='same', activation=None))
    if INFO['batch_norm']: model.add(BatchNormalization())
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(AveragePooling1D(pool_size=(2)))
    model.add(Conv1D(50, 5, padding='same', activation=None))
    if INFO['batch_norm']: model.add(BatchNormalization())
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(GlobalAveragePooling1D())
    model.add(Dense(100, activation=None))
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))


  elif model_type=='ECG1D':
    time_axis = -1
    model.add(InputLayer(shape=(n_timesteps, x_dim * y_dim, n_bands)))
    model.add(Reshape((n_timesteps, x_dim*y_dim*n_bands)) )

    for i in range(4):
      model.add(Conv1D(64, 5, activation=INFO['activation_name']))
      if INFO['batch_norm']: model.add(BatchNormalization())
      model.add(AveragePooling1D(pool_size=(2)))
      model.add(Dropout(INFO['dropout_rate']))

    model.add(Flatten())
    model.add(Dense(512, activation=INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))

  elif model_type=='CNN1DZ':
    time_axis = -1
    model.add(InputLayer(input_shape=(n_timesteps, x_dim * y_dim, n_bands)))
    model.add(Reshape((n_timesteps, x_dim*y_dim*n_bands)) )

    model.add(Conv1D(16, 5, activation=None))
    if batch_norm: model.add(BatchNormalization())
    model.add(Activation(Activation(activation_name)))
    model.add(AveragePooling1D(pool_size=(2)))
    model.add(Dropout(dropout_rate))

    model.add(Conv1D(32, 5, activation=None))
    if batch_norm: model.add(BatchNormalization())
    model.add(Activation(Activation(activation_name)))
    model.add(AveragePooling1D(pool_size=(2)))
    model.add(Dropout(dropout_rate))

    model.add(Conv1D(32, 5, activation=None))
    if batch_norm: model.add(BatchNormalization())
    model.add(Activation(Activation(activation_name)))
    model.add(AveragePooling1D(pool_size=(2)))
    model.add(Dropout(dropout_rate))

    model.add(Conv1D(32, 5, activation=None))
    if batch_norm: model.add(BatchNormalization())
    model.add(Activation(Activation(activation_name)))
    model.add(AveragePooling1D(pool_size=(2)))
    model.add(Dropout(dropout_rate))

    model.add(GlobalAveragePooling1D())
    model.add(Dense(32, activation=None))
    if batch_norm: model.add(BatchNormalization())
    model.add(Activation(Activation(activation_name)))
    model.add(Dropout(dropout_rate))

  elif model_type=='CNN2D':
    model.add(InputLayer(shape=(n_timesteps, x_dim , y_dim, n_bands)))
    model.add(Reshape((n_timesteps, x_dim*y_dim,n_bands)) )
    model.add(AveragePooling2D(pool_size=(5,1)))
    model.add(Conv2D(50, (5,5),  padding='same', activation=None))
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(AveragePooling2D(pool_size=(2,1)))
    model.add(Conv2D(50, (5,5),  padding='same', activation=None))
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(AveragePooling2D(pool_size=(2,1)))
    model.add(Conv2D(50, (5,2),  padding='same', activation=None))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(Flatten())
    model.add(Dense(100, activation=None))
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))

  elif model_type=='CNN3D':
    model.add(InputLayer(shape=(n_timesteps, x_dim , y_dim, n_bands)))
    model.add(AveragePooling3D(pool_size=(2,1,1)))
    model.add(Conv3D(50, (5,2,2),  padding='same', activation=None))
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(AveragePooling3D(pool_size=(2,1,1)))
    model.add(Conv3D(50, (5,2,2),  padding='same', activation=None))
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(AveragePooling3D(pool_size=(2,1,1)))
    model.add(Conv3D(50, (5,2,2),  padding='same', activation=None))
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(Flatten())
    model.add(Dense(100, activation=None))
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))
  elif model_type=='TimeDist': # Time distributed
    model.add(InputLayer(shape=(n_timesteps, x_dim , y_dim, n_bands)))
    model.add(AveragePooling3D(pool_size=(5,1,1))) 
    model.add(TimeDistributed(Conv2D(50, (3, 3), strides=(1, 1), activation=None, padding='same')))
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(TimeDistributed(Conv2D(50, (2, 2), strides=(1, 1), activation=None, padding='same')))
    model.add(Activation(INFO['activation_name']))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(TimeDistributed(Flatten()))
    model.add(LSTM(200, return_sequences=False))
    model.add(Dropout(INFO['dropout_rate']))
    model.add(Flatten())
    model.add(Dense(100))
    model.add(Dropout(INFO['dropout_rate']))
  else:
    raise Exception('Unkown Model')

  model.add(Dense(n_outputs, activation='softmax',kernel_constraint=max_norm(INFO['max_norm'])))
  if INFO['loss_function'] == 'focal_loss': loss_function = focal_loss()
  else: loss_function = INFO['loss_function']
  model.compile(loss=loss_function, optimizer=Adam(learning_rate=INFO['adam_learning_rate']), metrics=this.MODEL_METRICS)
  if INFO['show_summary']:
    model.summary()
  return model
######################### Function End ######################################


######################### Function Start ####################################
def split_data(data, Folds=5, validate_index=0, model_type=None, test_one_fold=False):
  # specify model_type when spliting x data to adjust the output according the the model

  data=data.copy()
  SZ = data.shape
  length = np.floor(SZ[0]/Folds).astype(int)
  start = length*validate_index
  if validate_index == Folds-1: end = SZ[0]
  else:   end = start + length
  #validate_index = np.ones(data.shape[0],dtype=bool)
  validate_index = np.zeros(data.shape[0],dtype=bool)
  validate_index[start:end] = True

  if test_one_fold:
    if validate_index == 0:
      start = SZ[0] - length
      end  = SZ[0]
    else:
      start = length*(validate_index-1)
      end = start + length
    #test_index = np.ones(data.shape[0],dtype=bool)
    test_index = np.zeros(data.shape[0],dtype=bool)
    test_index[start:end] = True

  validate = data[validate_index]
  if test_one_fold:
    test = data[test_index]
    train = data[np.invert(validate_index) & np.invert(test_index)]
  else:
    train = data[np.invert(validate_index)]


  # adjusting output depending on the model
  if model_type=='EEGNet_fusion':
    train=[train, train, train]
    validate=[validate, validate, validate]
    if test_one_fold:
      test=[test, test, test]


  if model_type=='CNN1D_MFBF':
    Bands=data[0].shape[-1]
    train=[np.expand_dims(train[:,:,:,i],axis=3) for i in range(Bands)]
    validate=[np.expand_dims(validate[:,:,:,i],axis=3) for i in range(Bands)]
    if test_one_fold:
      test=[np.expand_dims(test[:,:,:,i],axis=3) for i in range(Bands)]

  if test_one_fold: return train, validate, test
  else:return train, validate

########################## Function End #####################################

######################### Function Start ####################################
def split_subjects(data,data_subject_index,sub_part_index,fold, model_type=None, test_one_fold=False):

  validate_subject_index = np.arange(sub_part_index[fold],sub_part_index[fold+1])
  #validate_subject_index = np.array([validate_subject_index]).flatten()
  validate_index = np.zeros(len(data), dtype=bool)
  for sub_index in validate_subject_index:
    start = data_subject_index[sub_index,0]
    if sub_index == len(data_subject_index)-1:
      end=None
    else:
      end=data_subject_index[sub_index+1,0]
    validate_index[start:end] = True
  if test_one_fold:
    if fold == 0:test_fold = len(sub_part_index) - 2
    else: test_fold = fold - 1
    test_subject_index = np.arange(sub_part_index[test_fold],sub_part_index[test_fold+1])
    test_index = np.zeros(len(data), dtype=bool)
    for sub_index in test_subject_index:
      start = data_subject_index[sub_index,0]
      if sub_index == len(data_subject_index)-1:
        end=None
      else:
        end=data_subject_index[sub_index+1,0]
      test_index[start:end] = True

  validate = data[validate_index]
  if test_one_fold:
    test = data[test_index]
    train = data[np.invert(validate_index) & np.invert(test_index)]
  else:
    train = data[np.invert(validate_index)]

  # adjusting output depending on the model

  if model_type=='EEGNet_fusion':
    train=[train, train, train]
    validate=[validate, validate, validate]
    if test_one_fold:
      test = [test, test, test]

  if model_type=='CNN1D_MFBF':
    Bands=data[0].shape[-1]
    train=[np.expand_dims(train[:,:,:,i],axis=3) for i in range(Bands)]
    validate=[np.expand_dims(validate[:,:,:,i],axis=3) for i in range(Bands)]
    if test_one_fold:
      test=[np.expand_dims(test[:,:,:,i],axis=3) for i in range(Bands)]
  if test_one_fold:
    return train, validate, test
  else:
    return train, validate

########################## Function End #####################################

########################## Function Start #####################################
def evaluate_model(data_x, data_y, data_subject_index, INFO):

  # the following options force deterministic calculations, espcially on GPU, but makes the training up to 400%  slower
  if INFO['force_deterministic']:
    os.environ['TF_DETERMINISTIC_OPS'] = '1'
    os.environ['TF_CUDNN_DETERMINISTIC'] = '1'
    tf.config.experimental.enable_op_determinism()

  # Convert possibly ranges into lists
  INFO['folds'] = np.array(INFO['folds']).tolist()
  INFO['selected_subjects'] = np.array(INFO['selected_subjects']).tolist()
  INFO['selected_classes'] = np.array(INFO['selected_classes']).tolist()
  INFO['selected_channels'] = np.array(INFO['selected_channels']).tolist()
  INFO['selected_bands'] = np.array(INFO['selected_bands']).tolist()

  # Store classes
  INFO['classes'] = np.unique(data_y).tolist()

  if INFO['selected_classes'] is not None:
    print(f"Selected classes: {INFO['selected_classes']}")
    data_x, data_y, data_subject_index = select_classes(data_x, data_y, data_subject_index, INFO['selected_classes'])

  if INFO['selected_subjects'] is not None:
    if INFO['align_to_subject']:
      if INFO['fold_num'] > len(INFO['selected_subjects']) or any(x > INFO['fold_num']-1 for x in INFO['folds']):
        raise Exception("Folds does not match selected subject, please adjust folds")
    print(f"Selected subjects: {INFO['selected_subjects']}")
    data_x, data_y, data_subject_index = select_subjects(data_x, data_y, data_subject_index, INFO['selected_subjects'])

  if INFO['selected_channels'] is not None:
    print(f"Selected channels: {INFO['selected_channels']}")
    data_x = select_channels(data_x, INFO['selected_channels'])

  if INFO['selected_bands'] is not None:
    print(f"Selected bands: {INFO['selected_bands']}")
    data_x = select_bands(data_x, INFO['selected_bands'])



  INFO['data_shape'] = [list(data_x.shape),list(data_y.shape),list(data_subject_index.shape)]

  if INFO['shuffle']:
    if INFO['align_to_subject']:
      raise Exception("align_to_subject can't be True while shuffle is true")
    else:
      if INFO['shuffle_seed'] == 'auto': INFO['shuffle_seed'] = get_seed()
      np.random.seed(INFO['shuffle_seed'])
      indices = np.arange(len(data_x))
      np.random.shuffle(indices)
      data_x = data_x[indices]
      data_y = data_y[indices]

  Bands = data_x.shape[-1]
  INFO['bands'] = Bands
  for model_type in INFO['model_list']:
    INFO['model_type'] = model_type
    print(f'Starting evaluation for {model_type} model. Dataset: {INFO["dataset"]}, Classes:{INFO["selected_classes"] if INFO["selected_classes"]!=None else INFO["dataset"]}, Bands:{INFO["bands"]}, Folds: {list(INFO["folds"])}')
    if not INFO['use_class_weight']:
        print('Class weight is disabled')
    if INFO['fold_num'] > data_subject_index.shape[0] and INFO['align_to_subject']:
      raise ValueError('Number of folds should be less than number of subjects.')
    elif INFO['fold_num'] > data_x.shape[0]:
      raise ValueError('Number of folds should be less than number of segments.')

    if model_type in ['CNN3D', 'TimeDist']:
      data_x = make_into_2d(data_x, get_pos_map(INFO['dataset']))

    folds_to_skip = 0
    # check if partial output exist
    partial_folder = f'{this.RESULT_FOLDER}/partial'
    if os.path.exists(partial_folder) and os.path.isdir(partial_folder):
      print('Partial folder exists')
      json_file = f'{partial_folder}/info.json'
      if verify_json_match(INFO, json_file):
        folds_to_skip = line_count(f'{partial_folder}/training_loss.csv')
        if folds_to_skip > 0:
          print(f'Skipping the first {folds_to_skip} folds')
      else:
        rename_partial()


    for fold in INFO['folds'][folds_to_skip:]:
      if INFO['early_stopping_metric'] is not None:
        if INFO['early_stopping_metric'] == 'val_loss':
          callbacks = [
            EarlyStopping(
              monitor='val_loss',
              patience=INFO['early_stopping_patience'],
              restore_best_weights=True
            )
          ]
        elif INFO['early_stopping_metric'] == 'val_f1score':
          callbacks = [
            EarlyStopping(
              monitor='val_f1score',
              mode='max',
              patience=INFO['early_stopping_patience'],
              restore_best_weights=True
            )
          ]
        elif INFO['early_stopping_metric'] == 'val_recall':
          callbacks = [
            EarlyStopping(
              monitor='val_recall', # Matches the 'name' in your metrics + 'val_' prefix
              mode='max',
              patience=INFO['early_stopping_patience'],
              restore_best_weights=True
            )
          ]
        else: raise Exception('Unsupported stopping metrics')
      else:
        callbacks = []


      if INFO['fold_seeds'][fold] is not None:
        # setting seeds for each fold
        if INFO['fold_seeds'][fold] == 'auto': INFO['fold_seeds'][fold] = get_seed()
        seed = INFO['fold_seeds'][fold]
        random.seed(seed)
        np.random.seed(seed)
        tf.random.set_seed(seed)
        tf.keras.utils.set_random_seed(seed)
        os.environ["PYTHONHASHSEED"] = str(seed)
        tf.random.set_seed(seed)


      start_time = time.time()
      # Splitting data
      if INFO['align_to_subject']:
        # distributing subjects on folds in a fair way
        N = data_subject_index.shape[0]
        sub_part = np.ones(INFO['fold_num'])*np.floor(N/INFO['fold_num'])
        sub_part[0:(N % INFO['fold_num'])] +=1
        sub_part_index = np.append(0,np.cumsum(sub_part)).astype(np.int32)
        sub_test_index = np.arange(sub_part_index[fold],sub_part_index[fold+1])

        if INFO['test_one_fold']:
          train_x, validate_x, test_x = split_subjects(data_x,data_subject_index,sub_part_index, fold, model_type=model_type, test_one_fold=True)
          train_y, validate_y, test_y = split_subjects(data_y,data_subject_index,sub_part_index, fold, model_type=None, test_one_fold=True)
        else:
          train_x, validate_x = split_subjects(data_x,data_subject_index,sub_part_index, fold,model_type=model_type)
          train_y, validate_y = split_subjects(data_y,data_subject_index,sub_part_index, fold, model_type=None)
      else:
        if INFO['test_one_fold']:
          train_x, validate_x, test_x = split_data(data_x, Folds=INFO['fold_num'], validate_index=fold,model_type=model_type, test_one_fold=True)
          train_y, validate_y, test_y = split_data(data_y, Folds=INFO['fold_num'], validate_index=fold,model_type=None, test_one_fold = True)
        else:
          train_x, validate_x = split_data(data_x, Folds=INFO['fold_num'], validate_index=fold,model_type=model_type)
          train_y, validate_y = split_data(data_y, Folds=INFO['fold_num'], validate_index=fold,model_type=None)


      # Calculating number of classes for each fold
      vals, freq = np.unique(validate_y, return_counts=True)
      count_dict = dict(zip(vals, freq))
      fold_class_count = np.array([count_dict.get(x, 0) for x in INFO['classes'] ])


      if ('use_SMOTE' in INFO):
        if INFO['use_SMOTE']:
          # Let's assume your data_x is (segments, time, channels, bands)
          n_segments, n_time, n_channels, n_bands = data_x.shape
          # Flatten the non-segment dimensions
          # We keep the first dimension (segments) and collapse the rest
          train_x_flat = train_x.reshape(train_x.shape[0], -1)
          # Apply SMOTE to the training data only
          sm = SMOTE(sampling_strategy='not majority', random_state=42)
          train_x_res_flat, train_y_res = sm.fit_resample(train_x_flat, train_y)
          # Reshape trian_X back
          # The number of segments has now increased, but time/channels/bands stay the same
          train_x_res = train_x_res_flat.reshape(-1, n_time, n_channels, n_bands)
          train_x = train_x_res
          train_y = train_y_res

      # Generating categorical data
      train_yc = to_categorical(train_y)
      validate_yc = to_categorical(validate_y)
      #num_classes = train_yc.shape[1]


      # --- ✅ Compute Class Weights  ---
      class_weights_array = class_weight.compute_class_weight(
          class_weight="balanced",
          #classes=np.unique(y_integers),
          #y=y_integers
          classes=np.unique(train_y),
          y=train_y
      )
      class_weights = dict(enumerate(class_weights_array))



      print(f'Starting training: fold [{fold}], at {datetime.now(this.TIME_ZONE).strftime("%H:%M:%S")}. Class Weights: { {k: round(float(v), 3) for k, v in class_weights.items()} }.', end="")
      if INFO['align_to_subject']: print(f' Validation subjects {data_subject_index[sub_test_index,1]}.', end="")
      print("")

      if not INFO['use_class_weight']:
        class_weights = None

      # Building and validating  model
      model = build_model(train_x, train_yc, model_type,INFO)
      model.fit(train_x, train_yc, epochs=INFO['epochs'], batch_size=INFO['batch_size'],class_weight=class_weights, verbose=INFO['verbose'],  validation_data=(validate_x, validate_yc), callbacks=callbacks)

      if INFO['dataset'] in ['mitbih', 'incart', 'ptbxl']:
        target_names=['N', 'S', 'V', 'F', 'Q']
      else:
        target_names=np.array(INFO['classes']).astype(str).tolist()


      # saving F-score and generating confusion matrix
      # for training
      save_report(model, train_x, train_y,'training',fold,INFO,figure_size=(12,8), target_names=target_names)
      # for validation
      save_report(model, validate_x, validate_y,'validation',fold,INFO,figure_size=(12,8), target_names=target_names)
      if INFO['test_one_fold']:
        # for testing
        save_report(model, test_x, test_y,'testing',fold,INFO,figure_size=(12,8), target_names=target_names)

      metric_results = model.history.history
      fold_time = time.time() - start_time
      time_results = fold_time
      if INFO['align_to_subject']:
        subject_results = data_subject_index[sub_test_index,1]
      else:
        subject_results = None


      ACC=[]

      # saving predicted class accuracy for the current fold
      y_predict = np.argmax(model.predict(validate_x,verbose=0), axis = 1)

      for CLS in np.unique(validate_y): # classes
        index = np.flatnonzero(validate_y==CLS)
        ACC.append(np.sum(y_predict[index] == validate_y[index])/len(index) * 100)
      class_accuracy_results = ACC

      # saving partial results
      save_results(INFO,fold, metric_results,time_results, class_accuracy_results,subject_results, fold_class_count ,model=model)

      print(f'Fold {fold} done in {timedelta(seconds=round(fold_time))} ')

    # Finishing saving process
    save_finish(INFO)

  return model

########################## Function End #####################################

######################### Function Start ####################################
def test_model(data_x, data_y, data_subject_index,INFO):
  # Convert possibly ranges into lists
  INFO['folds'] = np.array(INFO['folds']).tolist()
  INFO['selected_subjects'] = np.array(INFO['selected_subjects']).tolist()
  INFO['selected_classes'] = np.array(INFO['selected_classes']).tolist()
  INFO['selected_channels'] = np.array(INFO['selected_channels']).tolist()
  INFO['selected_bands'] = np.array(INFO['selected_bands']).tolist()

  # Store classes
  INFO['classes']=np.unique(data_y).tolist()

  if INFO['selected_classes']!=None:
    print(f"Selected classes: {INFO['selected_classes']}")
    data_x, data_y, data_subject_index = select_classes(data_x, data_y, data_subject_index, INFO['selected_classes'])


  if INFO['selected_subjects']!=None:
    if INFO['align_to_subject']:
      if INFO['fold_num'] > len(INFO['selected_subjects']) or any(x > INFO['fold_num']-1 for x in INFO['folds']):
        raise Exception("Folds does not match selected subject, please adjust folds")
    print(f"Selected subjects: {INFO['selected_subjects']}")
    data_x, data_y, data_subject_index = select_subjects(data_x, data_y, data_subject_index, INFO['selected_subjects'])

  if INFO['selected_channels']!=None:
    print(f"Selected channels: {INFO['selected_channels']}")
    data_x = select_channels(data_x, INFO['selected_channels'])


  if INFO['selected_bands']!=None:
    print(f"Selected bands: {INFO['selected_bands']}")
    data_x = select_bands(data_x, INFO['selected_bands'])


  INFO['data_shape'] = [list(data_x.shape),list(data_y.shape),list(data_subject_index.shape)]


  if INFO['shuffle']:
    if INFO['align_to_subject']:
      raise Exception("align_to_subject can't be True while shuffle is true")
    else:
      np.random.seed(INFO['shuffle_seed'])
      indices = np.arange(len(data_x))
      np.random.shuffle(indices)
      data_x = data_x[indices]
      data_y = data_y[indices]


  Bands=data_x.shape[-1]
  INFO['bands']=Bands
  for model_name in INFO['test_models']:
    time.sleep(1) # waiting for 1 second to avoid similar time stamp
    # Loading model
    model_folder = f'{this.DATA_FOLDER}/models'
    os.makedirs(model_folder, exist_ok=True)
    model_path = f'{model_folder}/{model_name}'
    if not os.path.isfile(model_path): raise Exception(f'Model does not exist. Path: {model_path}')
    model = keras.models.load_model(model_path, compile=False)

    INFO['model_name']=model_name

    model_type = "_".join(model_name.split("_")[1:-1])
    INFO['model_type']=model_type
    print(f'Starting testing for {model_type} model. Dataset: {INFO["dataset"]}, Classes:{INFO["selected_classes"] if INFO["selected_classes"]!=None else INFO["dataset"]}, Bands:{INFO["bands"]}, Folds: {list(INFO["folds"])}')
    if INFO['fold_num'] > data_subject_index.shape[0] and INFO['align_to_subject']:
      raise ValueError('Number of folds should be less than number of subjects.')
    elif INFO['fold_num']>data_x.shape[0]:
      raise ValueError('Number of folds should be less than number of segments.')

    if model_type in ['CNN3D', 'TimeDist']: # these model requires 2D mapped data
      # Generating 2D mapped data
      pos_map = get_pos_map(INFO['dataset']) # positions for 2D map conversion
      data_x = make_into_2d(data_x,pos_map)

    if INFO['align_to_subject']:# distributing subjects on folds in a fair way
      N = data_subject_index.shape[0]
      sub_part = np.ones(INFO['fold_num'])*np.floor(N/INFO['fold_num'])
      sub_part[0:(N % INFO['fold_num'])] +=1
      sub_part_index = np.append(0,np.cumsum(sub_part)).astype(np.int32)



    for fold in INFO['folds']:
      start_time = time.time()
      # Splitting data
      if INFO['fold_num'] == 1:
        test_x = data_x
        test_y = data_y
        sub_test_index = np.arange(0,data_subject_index.shape[0])
      else:
        if INFO['align_to_subject']:
          sub_test_index = np.arange(sub_part_index[fold],sub_part_index[fold+1])
          _, test_x = split_subjects(data_x,data_subject_index,sub_test_index,model_type=model_type)
          _, test_y = split_subjects(data_y,data_subject_index,sub_test_index,model_type=None)
        else:
          _, test_x = split_data(data_x, Folds=INFO['fold_num'], validate_index=fold,model_type=model_type)
          _, test_y = split_data(data_y, Folds=INFO['fold_num'], validate_index=fold,model_type=None)

      # Calculating number of classes for each fold
      vals, freq = np.unique(test_y, return_counts=True)
      count_dict = dict(zip(vals, freq))
      fold_class_count = np.array([count_dict.get(x, 0) for x in INFO['classes'] ])


      # Generating categorical data
      test_yc = to_categorical(test_y)

      print(f'Starting testing: fold [{fold}], at {datetime.now(this.TIME_ZONE).strftime("%H:%M:%S")}.', end="")
      if INFO['align_to_subject']: print(f' Validation subjects {data_subject_index[sub_test_index,1]}.', end="")
      print("")

      if INFO['dataset'] in ['mitbih', 'incart', 'ptbxl']:
        target_names=['N', 'S', 'V', 'F', 'Q']
      else:
        target_names=np.array(INFO['classes']).astype(str).tolist()

      # saving F-score and generating confusion matrix
      save_report(model, test_x, test_y,'cross-testing',fold,INFO,figure_size=(12,8), target_names=target_names)



      if INFO['align_to_subject']:
        subject_results = data_subject_index[sub_test_index,1]
      else:
        subject_results = None


      ACC=[]

      # saving predicted class accuracy for the current fold
      y_predict = np.argmax(model.predict(test_x,verbose=0), axis = 1)

      for CLS in np.unique(test_y): # classes
        index = np.flatnonzero(test_y==CLS)
        ACC.append(np.sum(y_predict[index] == test_y[index])/len(index) * 100)
      class_accuracy_results = ACC

      # saving partial results
      save_tests(INFO,fold, class_accuracy_results,subject_results, fold_class_count)
      fold_time = time.time() - start_time
      print(f'Fold {fold} done in {timedelta(seconds=round(fold_time))} ')


    # Finishing saving process
    save_finish(INFO,cross_testing=True)

  return model

########################## Function End #####################################



######################### Function Start ###################################
def class_accuracy(datasets=this.DATASETS,save=False,label_info=['model_type']):
  if save:
    now = datetime.now(this.TIME_ZONE).strftime("%Y%m%d~%H%M%S")
    file_h = open(f'{this.RESULT_FOLDER}/class_accuracy~{now}.txt', "w")

  for dataset in datasets:
    files = sorted(glob.glob(f'{this.RESULT_FOLDER}/{dataset}~*/class_accuracy.csv'))
    if len(files)==0: continue

    dataset_line = f'===========================\n           {dataset}          \n****************************'
    print(dataset_line)
    if save: file_h.write(dataset_line+'\n')

    for file in files:

      with open(f'{os.path.dirname(file)}/info.json', "r") as f: INFO = json.load(f)
      Label = '-'*40 + '\n' + "-".join(str(INFO[key]) for key in label_info if key in INFO) + '\n' + '-'*40
      print(Label)
      if save: file_h.write(Label +'\n')

      # Load class accuracies
      with open(f'{os.path.dirname(file)}/class_accuracy.csv', "r") as f: line = f.readline()
      line=line.replace('[', '').replace(']', '').split(";")
      acc_array = np.array([np.fromstring(row, sep=',') for row in line]).transpose()
      avg_acc = np.mean(acc_array, axis=0)

      if INFO['align_to_subject']:
        with open(f'{os.path.dirname(file)}/subjects.csv', "r") as f: line = f.readline().strip()
        # Remove outer brackets safely
        line = line[1:-1]   # remove first [ and last ]
        # Split into groups
        groups_text = line.split('],[')
        subjects = []
        for grp in groups_text:
          arr = np.fromstring(grp, sep=' ', dtype=int)
          subjects.append(arr)
        folds = [f"{g[0]}-{g[-1]}" for g in subjects]
      else:
        folds = INFO['folds']

      Line =f'{"Subjects" if INFO["align_to_subject"] else "Folds":<9}:' + ':'.join(f'{a:>11}' for a in folds)
      print(Line)
      if save: file_h.write(Line +'\n')
      # Print average accuracies, formatted as 3.1 float
      Line = f'{"Average":<9}:'+ ':'.join(f'{a:11.1f}' for a in avg_acc)
      print(Line)
      if save: file_h.write(Line +'\n')

      # Print per-class accuracy rows
      for i, row in enumerate(acc_array):
        if INFO['selected_classes'] is not None:
          clc = f"{INFO['selected_classes'][i]}"
        else:
          clc = f"{i}"
        Line =f'{"Class " + clc:<9}:' + ':'.join(f'{a:11.1f}' for a in row)
        print(Line)
        if save: file_h.write(Line +'\n')
  if save: file_h.close()

  return
########################## Function End ######################################


######################### Function Start ###################################
def class_count(datasets=this.DATASETS, save=False, label_info=['model_type']):
  if save:
    now = datetime.now(this.TIME_ZONE).strftime("%Y%m%d~%H%M%S")
    file_h = open(f'{this.RESULT_FOLDER}/class_count~{now}.txt', "w")

  for dataset in datasets:
    files = sorted(glob.glob(f'{this.RESULT_FOLDER}/{dataset}~*/class_count.csv'))
    if len(files) == 0: continue

    dataset_line = f'===========================\n           {dataset}          \n****************************'
    print(dataset_line)
    if save: file_h.write(dataset_line + '\n')

    for file in files:
      with open(f'{os.path.dirname(file)}/info.json', "r") as f:
        INFO = json.load(f)

      Label = '-'*40 + '\n' + "-".join(str(INFO[key]) for key in label_info if key in INFO) + '\n' + '-'*40
      print(Label)
      if save: file_h.write(Label + '\n')

      # --- Parsing logic for class_count.csv ---
      with open(file, "r") as f:
        raw_data = f.readline().strip()

      # Remove trailing colon if it exists, then clean outer brackets
      raw_data = raw_data.rstrip(':').strip()
      # Split by '],' to isolate each fold's list
      parts = raw_data.split('],[')

      counts_list = []
      for p in parts:
        # Clean up any remaining brackets
        clean_p = p.replace('[', '').replace(']', '')
        # Convert space-separated string to numpy array
        counts_list.append(np.fromstring(clean_p, sep=' ', dtype=int))

      # Transpose so rows = classes, columns = folds
      count_array = np.array(counts_list).transpose()


      # --- Handle Subject/Fold labeling ---
      if INFO['align_to_subject']:
        with open(f'{os.path.dirname(file)}/subjects.csv', "r") as f:
          line = f.readline().strip()[1:-1]
        groups_text = line.split('],[')
        subjects = [np.fromstring(grp, sep=' ', dtype=int) for grp in groups_text]
        folds_labels = [f"{g[0]}-{g[-1]}" for g in subjects]
      else:
        folds_labels = [str(f) for f in INFO['folds']]

      # --- Header Row ---
      header = f'{"Subjects" if INFO["align_to_subject"] else "Folds":<9}:' + ':'.join(f'{f:>11}' for f in folds_labels)
      print(header)
      if save: file_h.write(header + '\n')


      # --- Per-Class Rows ---
      for i, row in enumerate(count_array):
        clc = f"{INFO['selected_classes'][i]}" if INFO.get('selected_classes') else f"{i}"
        row_str = f'{"Class " + clc:<9}:' + ':'.join(f'{int(val):11d}' for val in row)
        print(row_str)
        if save: file_h.write(row_str + '\n')

  if save:
    file_h.close()
  return
########################## Function End ######################################



######################### Function Start #####################################
def divide_time(data_x,data_y,N, data_subject_index=None):
  ax = 1 # this axis is the time samples
  if N not in range(1,21): raise ValueError("N must be between 1 and 20")
  if data_x.shape[ax] % N != 0: raise ValueError("Time samples in input data array must be multiple of N")
  if N==1: return data_x, data_y
  
  new_shape = list(data_x.shape)
  new_shape[ax-1] = data_x.shape[ax-1]*N
  new_shape[ax] = int(data_x.shape[ax]/N)
  data_x = np.reshape(data_x, new_shape)

  data_y = np.repeat(data_y,N)

  if data_subject_index is not None:
    data_subject_index_new=data_subject_index.copy()
    data_subject_index_new *= N
    return data_x, data_y, data_subject_index
  else:
    return data_x, data_y
########################## Function End ######################################


######################### Function Start #####################################
def plot_line(datasets=this.DATASETS,epochs=None, folds=None, metrics=this.METRICS,ylim=[0,100],save=False, figure_size=(6,4), show_title=True, show_legend=True,label_info=['model_type']):

  y_min = ylim[0]
  y_max = ylim[1]
  colors = ['red', 'blue','green','black','cyan',  'magenta' ,'brown','gray','teal']
  markers = ['s', '^', 'o', 'v','d','>','<','*','.']
  linestyles = ['solid','dotted']


  if save:
    now = datetime.now(this.TIME_ZONE).strftime("%Y%m%d~%H%M%S")
    plot_dir = f'{this.PLOT_FOLDER}/{now}'
    os.makedirs(f'{plot_dir}', exist_ok=True)


  for dataset in datasets:
    for metric in metrics:
      files = sorted(glob.glob(f'{this.RESULT_FOLDER}/{dataset}~*/{metric}.csv'))
      if len(files) == 0: continue
      #if "val_" not in metric:
        #files = [item for item in files if f"val_{metric}" not in item]
      sub_files = sorted(glob.glob(f'{this.RESULT_FOLDER}/{dataset}~*/subjects.csv'))


      DataSZ = 0
      plt.figure(figsize=figure_size)
      for index, file in enumerate(files):
        # finding subject count for each fold
        try:
          with open(sub_files[index],'r') as f: txt = f.read()
          txt=txt.replace('[', '').replace(']', '').split(',')
          sub_count = []
          for split in txt: sub_count.append(np.loadtxt(StringIO(split),dtype=int).size)
        except:
          sub_count = None
        if epochs is not None : data = np.genfromtxt(file, delimiter=',', usecols=range(epochs))
        else: data = np.genfromtxt(file, delimiter=',')
        if folds is not None: data = data[folds, :]
        data = data*100

        if DataSZ == 0: DataSZ = data.shape[-1]

        if len(data.shape)==1:
          mean = data
        else:
          if sub_count is None:
            mean = np.mean(data,axis=0)
          else:
            mean = np.sum(np.transpose(sub_count * np.transpose(data)),axis=0)/np.sum(sub_count)




        # loading evaluation_info from file
        with open(f'{os.path.dirname(file)}/info.json', "r") as f: INFO = json.load(f)
        Label = "-".join(str(INFO[key]) for key in label_info if key in INFO)

        plt.plot(mean,color=colors[index],linestyle = linestyles[0 if index <len(colors) else 1],linewidth=.7,marker=markers[index],markersize=5, markevery=20, label=Label)

      metric_name = metric.replace("cohen_", "").replace("_", " ")
      plt.xlabel('Epochs')
      plt.ylabel(f'Average {metric_name} %')
      plt.grid()
      plt.ylim(y_min,y_max)
      plt.yticks(np.arange(y_min,y_max+1,5))


      if show_title: plt.title(f'Average {metric_name} for {this.DATASET_NAMES[dataset]} dataset.')
      if show_legend: plt.legend(fontsize=8)
      if save:
        plt.savefig(f'{plot_dir}/{dataset}~{metric}.pdf')
      plt.show()
      plt.close()
  return
########################## Function End ######################################

######################### Function Start #####################################
def plot_bar(datasets=this.DATASETS, metrics=this.METRICS,save=False,ylim=[0,100],y_spacing=5,epochs=50, figure_size=(6,4), show_title=True, show_legend=True,label_info=['model_type']):
  results_subfolders = sorted([os.path.join(this.RESULT_FOLDER, f) for f in os.listdir(this.RESULT_FOLDER) if os.path.isdir(os.path.join(this.RESULT_FOLDER, f))])

  for subfolder in results_subfolders:
    last_dir = os.path.basename(os.path.normpath(subfolder))
    dataset = next((ds for ds in datasets if ds in last_dir), None)
    if not dataset: continue
    for metric in metrics:
      files = sorted(glob.glob(f'{subfolder}/{metric}.csv'))
      if len(files) == 0: continue
      for file in files:
        # Read the CSV file into a DataFrame
        df = pd.read_csv(file, header=None)  # Specify header=None to treat the first row as data
        # Extract the last values from each row and calculate their averages
        averages = df.apply(lambda row: np.mean(row.iloc[-epochs:]), axis=1)
        averages = averages*100
        # Create a bar plot with y-axis from 0% to 100% and x-axis from 1 to 24


        # loading evaluation_info from file
        with open(f'{os.path.dirname(file)}/info.json', "r") as f: INFO = json.load(f)
        Label = "-".join(str(INFO[key]) for key in label_info if key in INFO)



        # loading x labels
        if INFO['align_to_subject']:
          with open(f'{os.path.dirname(file)}/subjects.csv', "r") as f: line = f.readline().strip()
          # Remove outer brackets safely
          line = line[1:-1]   # remove first [ and last ]
          # Split into groups
          groups_text = line.split('],[')

          subjects = []
          for grp in groups_text:
            arr = np.fromstring(grp, sep=' ', dtype=int)
            subjects.append(arr)

          # Number of bars
          x = np.arange(len(subjects))
          # Label example: "100-109"
          x_labels = [f"{g[0]}-{g[-1]}" for g in subjects]
          x_label = "Subjects"

        else:
          x = np.array(range(len(df)))
          x_labels = INFO['folds']
          x_label = 'Folds'



        metric_name = metric.replace("cohen_", "").replace("_", " ")
        plt.figure(figsize=figure_size)
        plt.bar(x, averages,label=Label)
        plt.xlabel(x_label)
        plt.ylabel(f'Average {metric_name} %')
        if show_title: plt.title(f'Average {metric_name} for {this.DATASET_NAMES[dataset]} dataset')
        if show_legend: plt.legend(fontsize=8)
        plt.ylim(ylim)  # Set the y-axis range from 0 to 100

        # Set x-axis ticks and labels
        plt.xticks(x, labels=x_labels)
        plt.yticks(np.arange(ylim[0], ylim[1]+1, y_spacing))
        plt.grid(True, axis='y', linestyle='--')
        if save:
          file_dir = os.path.basename(os.path.dirname(file))
          plot_dir = f'{this.BARPLOT_FOLDER}/{file_dir}'
          os.makedirs(f'{plot_dir}', exist_ok=True)
          plt.savefig(f'{plot_dir}/{metric}.pdf')
        plt.show()
        plt.close()
  return
########################## Function End ######################################

######################### Function Start #####################################
def plot_multibar(datasets=None, save=False, label_info=['model_type'],figure_size=(6,4), show_title=True, show_legend=True,show_bar_label=False):

  files = [f for ds in datasets for f in glob.glob(f'{this.RESULT_FOLDER}/{ds}~*/class_accuracy.csv')]
  if not files:
    print("No files found.")
    return
  files=sorted(files)
  for file in files:

    # Loading evaluation_info from file
    info_path = f'{os.path.dirname(file)}/info.json'
    with open(info_path, "r") as f:
      INFO = json.load(f)

    # Read the CSV file
    with open(file, "r") as f:
      line = f.readline()

    line = line.replace('[', '').replace(']', '').split(";")
    acc_array = np.array([np.fromstring(row, sep=',') for row in line])

    num_folds, num_classes = acc_array.shape

    # Loading x labels
    if INFO['align_to_subject']:
      with open(f'{os.path.dirname(file)}/subjects.csv', "r") as f:
        line = f.readline()
      line = line.replace('[', '').replace(']', '')
      x = np.fromstring(line, sep=',', dtype=int)
      x_label = 'Subjects'
    else:
      x = np.array(range(num_folds))
      x_label = 'Classes for each fold'

    bar_width = 0.8 / num_classes
    plt.figure(figsize=figure_size)
    ax = plt.gca()

    for i in range(num_classes):
      if INFO['selected_classes'] is not None:
        class_name = f"Class {INFO['selected_classes'][i]}"
        short_label = f"{INFO['selected_classes'][i]}"
      else:
        class_name = f"Class {INFO['classes'][i]}"
        short_label = f"{INFO['classes'][i]}"

      # Plot bars
      rects = ax.bar(x + i * bar_width, acc_array[:, i], width=bar_width, label=class_name)

      # Add class label text over each bar
      # We use short_label (e.g., C1) to save space
      if show_bar_label: ax.bar_label(rects, labels=[short_label] * len(rects), padding=3, fontsize=8, rotation=90)

    title_suffix = "-".join(str(INFO[key]) for key in label_info if key in INFO)
    dataset_name = this.DATASET_NAMES[INFO['dataset']]

    plt.xlabel(x_label)
    plt.ylabel('Tested accuracy per class %')
    if show_title: plt.title(f"Tested accuracy per class for {dataset_name} dataset\n{title_suffix}")

    # Adjust ticks to be centered relative to the group of bars
    plt.xticks(x + (bar_width * (num_classes - 1) / 2), labels=x)
    plt.yticks(np.arange(0, 101, 5))
    plt.ylim(0, 115) # Increased limit to give room for labels
    if show_legend: plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.grid(axis='y', linestyle='--')
    plt.tight_layout()

    if save:
      plot_dir = f'{this.BARPLOT_FOLDER}/{os.path.basename(os.path.dirname(file))}'
      os.makedirs(plot_dir, exist_ok=True)
      plt.savefig(f'{plot_dir}/multibar.pdf')

    plt.show()
    plt.close()

  return

########################## Function End ######################################

######################### Function Start #####################################
def plot_segment(data_x, data_y, data_subject_index, subject="random",  segment="random", class_label="random", channel="random", band="random",show_title=True,save=False):


  # --- Choose subject ---
  if subject == "random":
    subj_idx = random.randint(0, data_subject_index.shape[0] - 1)
  else:
    subj_idx = np.where(data_subject_index[:, 1] == subject)[0][0]

  start = data_subject_index[subj_idx, 0]
  if subj_idx < data_subject_index.shape[0] - 1:
    end = data_subject_index[subj_idx + 1, 0]
  else:
    end = data_x.shape[0]

  subject_segments = np.arange(start, end)

  # --- Choose class ---
  if class_label == "random":
    class_candidates = subject_segments
  else:
    class_candidates = subject_segments[data_y[subject_segments] == class_label]

  if len(class_candidates) == 0:
    raise ValueError("No segments found for this subject/class combination.")

  # --- Choose segment ---
  if segment == "random":
    segment_idx = random.choice(class_candidates)
  else:
    segment_idx = subject_segments[int(segment)]

  # --- Choose channel ---
  n_channels = data_x.shape[2]
  if channel == "random":
    channel_idx = random.randint(0, n_channels - 1)
  else:
    channel_idx = channel

  # --- Choose band ---
  n_bands = data_x.shape[3]
  if band == "random":
    band_idx = random.randint(0, n_bands - 1)
  else:
    band_idx = band


  if save:
    now = datetime.now(this.TIME_ZONE).strftime("%Y%m%d~%H%M%S")
    plot_dir = f'{this.PLOT_FOLDER}'
    os.makedirs(f'{plot_dir}', exist_ok=True)



  # --- Extract and plot ---
  signal = data_x[segment_idx, :, channel_idx, band_idx]
  CLS = data_y[segment_idx]
  subj_id = data_subject_index[subj_idx, 1]

  plt.figure(figsize=(10, 4))
  plt.plot(signal, lw=1.2)
  if show_title: plt.title(f"Subject {subj_id}, Segment {segment_idx}, Class {CLS}, Channel {channel_idx}, Band {band_idx}")
  plt.xlabel("Time Samples")
  plt.ylabel("Amplitude")
  plt.grid(True, alpha=0.3)
  plt.tight_layout()
  if save:
    plt.savefig(f'{plot_dir}/Raw_S{subj_id}_T{segment_idx}_CL{CLS}_CH{channel_idx}_B{band_idx}.pdf')
  plt.show()
  plt.close()
  return

######################### Function End #####################################

######################### Function Start #####################################
def average_results(datasets=this.DATASETS, metrics=this.METRICS,epochs=50, save=False, label_info=['model_type']):

  if save:
    now = datetime.now(this.TIME_ZONE).strftime("%Y%m%d~%H%M%S")
    file_h = open(f'{this.RESULT_FOLDER}/average~{now}.txt', "w")


  for dataset in datasets:
    files = glob.glob(f'{this.RESULT_FOLDER}/{dataset}~*/*.csv')
    if len(files)==0: continue
    dataset_line = f'===========================\n           {dataset}          \n****************************'
    print(dataset_line)
    if save: file_h.write(dataset_line+'\n')

    for metric in metrics:
      heading = f'-------- {metric}-----------'
      if save:
        file_h.write(heading+'\n')
      print(heading)

      metric_files = sorted(glob.glob(f'{this.RESULT_FOLDER}/{dataset}~*/{metric}.csv'))
      if len(metric_files) == 0: continue
      subject_files = sorted(glob.glob(f'{this.RESULT_FOLDER}/{dataset}~*/subjects.csv'))
      #if len(subject_files) == 0: continue



      DataSZ = 0
      for index, metric_file in enumerate(metric_files):
        # finding subject count for each fold
        try:
          with open(subject_files[index],'r') as f: txt = f.read()
          txt=txt.replace('[', '').replace(']', '').split(',')
          subject_count = []
          for split in txt: subject_count.append(np.loadtxt(StringIO(split),dtype=int).size)
        except:
          subject_count = None


        data = np.genfromtxt(metric_file, delimiter=',')
        data=100*data

        # if DataSZ == 0: DataSZ = data.shape[-1]
        DataSZ = data.shape[-1]

        if len(data.shape)==1:
          mean = data
        else:
          if subject_count is None:
            mean = np.mean(data,axis=0)
          else:
            mean = np.sum(np.transpose(subject_count * np.transpose(data)),axis=0)/np.sum(subject_count)

        with open(f'{os.path.dirname(metric_file)}/info.json', "r") as f: INFO = json.load(f)
        Label = "-".join(str(INFO[key]) for key in label_info if key in INFO)

        line = f'{Label:30}Mean({DataSZ-epochs}-{DataSZ}) = {np.mean(mean[DataSZ-epochs:DataSZ]):0.1f}'
        if save: file_h.write(line+'\n')
        print(line)
  if save: file_h.close()


  return
########################## Function End ######################################



######################### Function Start #####################################
def validation_time(datasets=this.DATASETS, save=False,label_info=['model_type']):
  if save:
    now = datetime.now(this.TIME_ZONE).strftime("%Y%m%d~%H%M%S")
    file_h = open(f'{this.RESULT_FOLDER}/duration~{now}.txt', "w")

  for dataset in datasets:
    files = glob.glob(f'{this.RESULT_FOLDER}/{dataset}~*/*.csv')
    if len(files)==0: continue

    dataset_line = f'===========================\n           {dataset}          \n****************************'
    print(dataset_line)
    if save: file_h.write(dataset_line+'\n')

    files = sorted(glob.glob(f'{this.RESULT_FOLDER}/{dataset}~*/time.csv'))
    if len(files) == 0: continue
    for file in files:
      file_dir = os.path.basename(os.path.dirname(file))

      with open(f'{os.path.dirname(file)}/info.json', "r") as f: INFO = json.load(f)
      Label = "-".join(str(INFO[key]) for key in label_info if key in INFO)
      data = np.genfromtxt(file, delimiter=',')
      line = f'{Label:30}   {time_format(np.round(np.sum(data)))}'
      if save: file_h.write(line+'\n')
      print(line)
  if save: file_h.close()

  return
########################## Function End ######################################

######################### Function Start #####################################
def save_results(INFO,fold,metric_results,time_results,class_accuracy_results,subject_results, fold_class_count, model=None):

  os.makedirs(this.RESULT_FOLDER, exist_ok=True)
  save_folder = f'{this.RESULT_FOLDER}/partial'
  os.makedirs(save_folder, exist_ok=True)
  now = datetime.now(this.TIME_ZONE).strftime("%Y%m%d~%H%M%S")
  INFO['time_stamp'] = now


  # saving model
  model.save(f'{save_folder}/{INFO["dataset"]}_{INFO["model_type"]}_{fold}.keras')


  # Saving information
  with open(f'{save_folder}/info.json', "w") as f:
    json.dump(INFO, f)

  # appending metrics
  for metric in this.METRICS:
    key = metric.replace('training_','').replace('validation_','val_')
    if not key in metric_results: continue
    file_h = open(f'{save_folder}/{metric}.csv', "a")
    writer = csv.writer(file_h)
    writer.writerow([f'{x:0.4f}' for x in metric_results[key]])
    file_h.close()


  # appending evaluation time to the same line
  time_file = f'{save_folder}/time.csv'
  file_exists = os.path.exists(time_file) and os.path.getsize(time_file) > 0
  with open(time_file, "a") as f:
    if file_exists: f.write(',')
    f.write(f"{time_results:0.2f}")

  # appending subject results
  if subject_results is not None:
    subject_file = f'{save_folder}/subjects.csv'
    file_exists = os.path.exists(subject_file) and os.path.getsize(subject_file) > 0
    with open(subject_file, "a") as f:
      if file_exists:  f.write(',')
      f.write(f"{subject_results}")


  # appending fold class count results
  class_count_file = f'{save_folder}/class_count.csv'
  file_exists = os.path.exists(class_count_file) and os.path.getsize(class_count_file) > 0
  with open(class_count_file, "a") as f:
    if file_exists:  f.write(',')
    f.write(f"{fold_class_count}")

  # appending accuracy (per class) results as [val, val]
  class_acc_file = f'{save_folder}/class_accuracy.csv'
  file_exists = os.path.exists(class_acc_file)
  formatted_row = "[" + ", ".join([f"{float(x):.3f}" for x in class_accuracy_results]) + "]"
  with open(class_acc_file, "a") as f:
    if file_exists and os.path.getsize(class_acc_file) > 0:  f.write(";")
    f.write(formatted_row)
  return

########################## Function End ######################################

######################### Function Start #####################################
def save_tests(INFO,fold,class_accuracy_results,subject_results, fold_class_count):

  os.makedirs(this.CROSS_TEST_FOLDER, exist_ok=True)
  save_folder = f'{this.CROSS_TEST_FOLDER}/partial'
  os.makedirs(save_folder, exist_ok=True)
  now = datetime.now(this.TIME_ZONE).strftime("%Y%m%d~%H%M%S")
  INFO['time_stamp'] = now

  # Saving information
  with open(f'{save_folder}/info.json', "w") as f:
    json.dump(INFO, f)

  # appending subject results
  if subject_results is not None:
    subject_file = f'{save_folder}/subjects.csv'
    file_exists = os.path.exists(subject_file) and os.path.getsize(subject_file) > 0
    with open(subject_file, "a") as f:
      if file_exists:  f.write(',')
      f.write(f"{subject_results}")


  # appending fold class count results
  class_count_file = f'{save_folder}/class_count.csv'
  file_exists = os.path.exists(class_count_file) and os.path.getsize(class_count_file) > 0
  with open(class_count_file, "a") as f:
    if file_exists:  f.write(',')
    f.write(f"{fold_class_count}")

  # appending accuracy (per class) results as [val, val]
  class_acc_file = f'{save_folder}/class_accuracy.csv'
  file_exists = os.path.exists(class_acc_file)
  formatted_row = "[" + ", ".join([f"{float(x):.3f}" for x in class_accuracy_results]) + "]"
  with open(class_acc_file, "a") as f:
    if file_exists and os.path.getsize(class_acc_file) > 0:  f.write(";")
    f.write(formatted_row)
  return
########################## Function End ######################################

######################### Function Start #####################################
def dct_1d(data_x):
  from scipy import fft

  # find 1 dimentional dct for x_data
  data_x_out = fft.dct(data_x, axis=1)

  return data_x_out
########################## Function End ######################################

######################### Function Start #####################################
def fft_1d(data_x):
    # find 1 dimentional fft for x_data
  data_x_out = np.abs(np.fft.fft(data_x, axis=1))

  return data_x_out
########################## Function End ######################################



######################### Function Start #####################################
def get_chbmit_array(gap):

  # first dimension: subjects
  # second dimension: stages (ictal, preictal, interictal)
  # third dimension: [ file name, start time (seconds), end time (seconds)]
  # The file chb02_16+.edf is taken instead of chb02_16.edf.
  # for subject No. 4 files > chb06, remove channel 24 (ECG)
  # for subject No. 9 files > chb01, remove channel 24 (VNS)
  # for subject No. 11 files > chb01, remove channels:  5,10, 13, 18, 23,




  # generating ictal array using code

  path=f'{this.CONTENT_FOLDER}/physionet.org/files/chbmit/1.0.0/'
  url='https://physionet.org/files/chbmit/1.0.0/'

  ictal_list=[]
  for subject in range(1,25):
      ictal_list.insert(subject-1,[])
      file_path  = path + f'chb{subject:02d}/chb{subject:02d}-summary.txt'
      file_url = url + f'chb{subject:02d}/chb{subject:02d}-summary.txt'
      get_ipython().system(f'wget -c -q --show-progress {file_url} -P {os.path.dirname(file_path)}')

      with open(file_path, 'r') as file:
          lines = [line.strip() for line in file.readlines()]
      i=-1
      while True:
          i+=1
          if(i>=len(lines)): break
          if(lines[i].find("File Name:")>=0):
              file_name = re.search(r'chb.+edf', lines[i]).group()
              while True:
                  i+=1
                  if(lines[i].find("Number of Seizures in File:")>=0): break
              num = int(lines[i].split()[-1])
              if num > 0:
                  for s in range(num):
                      i+=1
                      start = int(re.search(r':\s*(\d+)', lines[i]).group(1))
                      i+=1
                      end = int(re.search(r':\s*(\d+)', lines[i]).group(1))
                      ictal_list[subject-1].append([file_name, start, end])
              else: continue
          else: continue




  # appending space for preictal data
  data=[]
  for i in range(len(ictal_list)):
    # Insert elements from list1 and list2 at the same index
    data.insert(i,[])
    data[i].append(ictal_list[i])
    data[i].append([])


    # generating preictal data
  for subject in range(len(data)):
    previous_end = 0
    previous_file = ""
    event = 0
    index = 0
    while event < len(data[subject][0]):
      index=index+1
      # Assuming the third dimension always has at least 3 elements
      file = data[subject][0][event][0]
      start = data[subject][0][event][1] - gap
      end = data[subject][0][event][2] - gap
      if file != previous_file: previous_end = 0
      previous_file = file
      if start < previous_end:
        print (f"Excluding: Ictal[{index}] Subject[{subject+1}] No enough time for preictal")
        if index==len(data[subject][0]) and event==0:
          raise Exception("\n"+f" No remaining ictals for subject[{subject+1}]")
        del data[subject][0][event]
        previous_end = data[subject][0][event][2]
        continue
      else:
        data[subject][1].insert(event,[file, start, end])
        previous_end = data[subject][0][event][2]
        event+=1


  # the selected files for interictal stage for each subject
  interictal_files = [
    ['chb01_09.edf', 'chb01_10.edf','chb01_36.edf','chb01_37.edf'],
    ['chb02_08.edf','chb02_28.edf'],
    ['chb03_18.edf','chb03_19.edf','chb03_20.edf'],
    ['chb04_17.edf','chb04_36.edf'],
    ['chb05_30.edf','chb05_31.edf','chb05_32.edf'],
    ['chb06_07.edf','chb06_16.edf'],
    ['chb07_05.edf','chb07_06.edf','chb07_07.edf'],
    ['chb08_17.edf'],
    ['chb09_13.edf','chb09_14.edf'],
    ['chb10_04.edf','chb10_16.edf'],
    ['chb11_10.edf','chb11_11.edf','chb11_12.edf'],
    ['chb12_20.edf','chb12_40.edf'],
    #['chb13_09.edf','chb13_10.edf','chb13_36.edf'],
    ['chb13_03.edf'],
    ['chb14_24.edf','chb14_37.edf'],
    ['chb15_03.edf','chb15_33.edf'],
    ['chb16_04.edf','chb16_05.edf','chb16_06.edf'],
    ['chb17b_57.edf','chb17c_04.edf'],
    ['chb18_14.edf','chb18_15.edf'],
    ['chb19_13.edf','chb19_14.edf','chb19_15.edf'],
    ['chb20_05.edf','chb20_27.edf','chb20_28.edf'],
    ['chb21_09.edf','chb21_10.edf','chb21_28.edf'],
    ['chb22_08.edf','chb22_09.edf'],
    ['chb23_17.edf'],
    ['chb24_19.edf']]



  # generating interictal array
  for subject in range(len(data)):
    data[subject].append([])
    selected_file = 0
    file_position = [0]*len(interictal_files[subject])
    for phase in range(len(data[subject][0])):
      data[subject][2].insert(phase,[])
      start = file_position[selected_file]
      end = start + (data[subject][0][phase][2] - data[subject][0][phase][1])
      data[subject][2][phase]=[interictal_files[subject][selected_file], start, end]
      file_position[selected_file] = end
      selected_file+=1
      if selected_file >= len(interictal_files[subject]): selected_file  = 0

  return data
########################## Function End ######################################

########################## Function Start ######################################
def read_raw(edf_filename, selected_ch_names):
  url_name = 'https://physionet.org/files/chbmit/1.0.0/' + edf_filename.split("/")[-2] + '/' + edf_filename.split("/")[-1]
  get_ipython().system(f'wget  -q -c --show-progress  {url_name} -P {os.path.dirname(edf_filename)}')


  raw = mne.io.read_raw_edf(edf_filename,stim_channel=None, exclude=('-'),verbose="ERROR")

  if 'T8-P8-1' in raw.info.ch_names:
    #X1 = raw.get_data(picks='T8-P8-0').astype(np.float32)
    #X2 = raw.get_data(picks='T8-P8-1').astype(np.float32)
    #if not np.array_equal(X1, X2):
      #print(f'Duplicates channels are not equals for file {edf_filename}')
    raw.drop_channels('T8-P8-1')
    raw.rename_channels({'T8-P8-0' : 'T8-P8'})

  if raw.info.ch_names!=selected_ch_names:
    raw.reorder_channels(selected_ch_names)

  return raw
########################## Function End ######################################


########################## Function Start ######################################
def stack_lists(list1, list2, list3=None):
  # Ensure the input lists have the same length
  if len(list1) != len(list2):
      raise ValueError("Input lists must have the same length")

  # Create a new list to hold the stacked lists
  stacked_list = []

  # Iterate over the indices and insert elements from both lists
  for i in range(len(list1)):
    # Insert elements from list1 and list2 at the same index
    stacked_list.insert(i,[])
    stacked_list[i].append(list1[i])
    stacked_list[i].append(list2[i])
    if list3 is not None:
      stacked_list[i].append(list3[i])

  return stacked_list
########################## Function End ######################################

########################## Function Start ######################################
def imfs(data_x, N=3):
  start_time = time.time()
  """
  Convert single-band EEG data to IMF-multiband form.

  Parameters:
    data_x: ndarray of shape (segments, samples, channels, bands)
            bands must be 1
    N: number of IMFs to extract per signal

  Returns:
    data_X_imfs: ndarray of shape (segments, samples, channels, N)
  """
  assert data_x.shape[-1] == 1, "Expected only one band in the input"
  segments, samples, channels, bands = data_x.shape

  emd = EMD()
  data_x_imfs = np.zeros((segments, samples, channels, N))

  for t in range(segments):
    for c in range(channels):
      signal = data_x[t, :, c, 0]  # (single value or short segment)

      # If signal is just a value, skip (no point in EMD on scalars)
      if isinstance(signal, (int, float, np.number)):
        print(data_x.shape)
        print(signal.shape)
        print("no IMFs for (Just scaler) Signals")
        continue

      imfs = emd(signal)
      num_imfs = min(N, imfs.shape[0])
      data_x_imfs[t, :, c, :num_imfs] = imfs[:num_imfs].T
    print(f"\rIMFs for segment {t}/{segments} is done", end = '')

  print("\nsize of data_x after imfs is ", data_x_imfs.shape)
  print(f'Total Time for IMFs = {timedelta(seconds=round(time.time() - start_time))}')
  return data_x_imfs
########################## Function End ######################################

########################## Function Start ######################################
def select_channels(data_x, selected_channels):
  if isinstance(selected_channels, int):
    selected_channels = [selected_channels]  # wrap in list
  return data_x[:, :, selected_channels, :]
########################## Function End ######################################

########################## Function Start ######################################
def show_class_stats(data_subject_index,data_y):

  sub_num = len(data_subject_index)
  cls_val = np.unique(data_y)
  class_num = len(cls_val)

  sub_cls_count = np.zeros((class_num,sub_num),dtype=int)

  for sub_index in range(sub_num):
    start=data_subject_index[sub_index,0]
    if sub_index < (sub_num - 1):
      end = data_subject_index[sub_index+1,0]
    else:
      end = len(data_y)
    val, cnt = np.unique(data_y[start:end], return_counts=True)
    val_indices = np.searchsorted(cls_val, val)
    sub_cls_count[val_indices,sub_index] = cnt

  MIN = np.min(sub_cls_count, axis=1)
  MAX = np.max(sub_cls_count, axis=1)
  SUM = np.sum(sub_cls_count, axis=1)

  TAB = 8
  print(f"{'Class':<{TAB}}{'MIN':<{TAB}}{'MAX':<{TAB}}{'SUM':<{TAB}}")
  for index in range (class_num):
    print(f"{cls_val[index]:<{TAB}}{MIN[index]:<{TAB}}{MAX[index]:<{TAB}}{SUM[index]:<{TAB}}")

  print("")

  TAB1=12
  # Header: Uses len(counts) because 'counts' is the tuple of subjects (the columns)
  print(f"{'Subjects:':<{TAB1}}" + "".join([f'{f"{i}":<{TAB}}' for i in data_subject_index[:,1]]))

  print(f"{'Classes:':<{TAB1}}" + "".join([f"{np.count_nonzero(sub_cls_count[:, i]):<{TAB}}" for i in range(sub_num)]))

  total_width = TAB1 + (len(data_subject_index[:, 1]) * TAB)
  print("-" * total_width)

  # Rows: Uses len(counts[0]) because that represents the number of elements/classes (the rows)
  for index in range(class_num):
    print(f"{'Class: ' +str(cls_val[index]):<{TAB1}}"+ "".join([f"{count:<{TAB}}" for count in sub_cls_count[index]]))

  return
########################## Function End ######################################


########################## Function Start ######################################
def select_bands(data_x, selected_bands):
  if isinstance(selected_bands, int):
    selected_bands = [selected_bands]  # wrap in list
  return data_x[:, :, :, selected_bands]
########################## Function End ######################################

########################## Function Start ######################################
def time_format(s):
  s = int(s)
  h = s//3600
  s = s % 3600
  m = s // 60
  s = s % 60
  return f'{h:02n}:{m:02n}:{s:02n}'
########################## Function End ######################################

########################## Function Start ######################################
def resample_data(x_data, old_fs, new_fs, pad_samples=20):
    if x_data.ndim != 4:
        raise ValueError("x_data must be a 4D array: (segments, time, channels, bands)")

    up = new_fs
    down = old_fs

    # Reflect padding along time axis (axis=1)
    pad_width = [(0, 0)] * x_data.ndim
    pad_width[1] = (pad_samples, pad_samples)
    x_padded = np.pad(x_data, pad_width=pad_width, mode='reflect')

    # Resample
    x_resampled_padded = resample_poly(x_padded, up, down, axis=1)

    # Calculate trim
    trim = int(np.round(pad_samples * up / down))

    # Trim padding
    x_resampled = x_resampled_padded[:, trim:-trim, :, :]

    # Enforce exact expected output length
    expected_len = int(np.round(x_data.shape[1] * new_fs / old_fs))
    x_resampled = fix_time_dimension(x_resampled, expected_len)

    return x_resampled

########################## Function End ######################################

########################## Function Start ######################################
def save_data(data_x, data_y, data_subject_index, INFO):
  sub_folder = f"{INFO['dataset']}_" + datetime.now(this.TIME_ZONE).strftime("%Y%m%d-%H%M%S")
  save_folder = f"{COLEEG.DATA_FOLDER}/save/{sub_folder}"
  os.makedirs(save_folder, exist_ok=True)
  with open(f"{save_folder}/info.json", "w") as f: json.dump(INFO, f)
  np.save(f"{save_folder}/data_x_{INFO['dataset']}_{INFO['sampling_freq']}Hz_{INFO['bands']}.npy", data_x)
  np.save(f"{save_folder}/data_y_{INFO['dataset']}_{INFO['sampling_freq']}Hz_{INFO['bands']}.npy", data_y)
  np.save(f"{save_folder}/data_subject_index_{INFO['dataset']}_{INFO['sampling_freq']}Hz_{INFO['bands']}.npy", data_subject_index)
  print(f"Data saved in folder {sub_folder}")
########################## Function End ######################################

########################## Function Start ######################################
def load_data(folder):
  save_folder = f"{COLEEG.DATA_FOLDER}/save/{folder}"
  if not os.path.isdir(save_folder): raise ValueError(f'{save_folder} does not exist')
  file = glob.glob(f'{save_folder}/data_x*.npy')
  if len(file)!=1 : raise ValueError("data_x file loading error")
  data_x = np.load(file[0])
  file = glob.glob(f'{save_folder}/data_y*.npy')
  if len(file)!=1 : raise ValueError("data_y file loading error")
  data_y = np.load(file[0])
  file = glob.glob(f'{save_folder}/data_subject_index*.npy')
  if len(file)!=1 : raise ValueError("data_subject_index file loading error")
  data_subject_index = np.load(file[0])
  file = glob.glob(f'{save_folder}/info.json')
  if len(file)!=1 : raise ValueError("info.json file loading error")
  with open(file[0], "r") as f: INFO = json.load(f)

  # Fixing 'class_max' key, because it is read as string
  if 'class_max' in INFO: INFO['class_max'] = {int(k): v for k, v in INFO['class_max'].items()}

  return data_x, data_y, data_subject_index, INFO
########################## Function End ######################################

########################## Function Start ######################################
def verify_json_match(data_dict, file_path):
  # matching INFO dictinary to INFO.json file, excluding time_stamp key.
  try:
    with open(file_path, 'r') as f:
      file_data = json.load(f)

    mismatched_fields = []
    ignored_keys = {'time_stamp'}

    for key, value in file_data.items():
      if key in ignored_keys:
        continue

      # JSON keys are always strings. If we are looking at class_max,
      # we convert its keys to integers so they match your Python dict.
      if key == 'class_max':
        value = {int(k): v for k, v in value.items()}

      # Check if key exists in file and if the value matches
      if key not in data_dict or data_dict[key] != value:
        mismatched_fields.append(key)

    if not mismatched_fields:
      print("INFO file matched.")
      return True
    else:
      print("The following fields in INFO file did not match:")
      for field in mismatched_fields:
        print(f" - {field}")
      return False

  except FileNotFoundError:
    print("Error: INFO file not found.")
    return False
  except json.JSONDecodeError:
    print("Error: Failed to decode INFO file.")
    return False
########################## Function End ######################################

########################## Function Start ######################################
def line_count(file_path):
  # get number of lines that have actual text
  with open(file_path, 'r') as f:
    # Generates 1 for every line that isn't empty after stripping
    return sum(1 for line in f if line.strip())
########################## Function End ######################################

########################## Function Start ######################################
def debug(*args):
  # utility  function to avoid using print for displaying debug information
  print("DEBUG: ", *args)
########################## Function End ######################################

########################## Function Start ######################################
def save_report(model, x_data, y_data, suffix, fold,INFO, figure_size=(12,8), font_size=20, target_names=['0', '1', '2', '3', '4']):
  if suffix == 'cross-testing':save_folder = this.CROSS_TEST_FOLDER
  else: save_folder = this.RESULT_FOLDER

  # 1. Get predictions - Silent mode to prevent model.fit-style progress bars
  y_pred_probs = model.predict(x_data, verbose=0)
  y_pred = np.argmax(y_pred_probs, axis=1)

  # Check if y_data is one-hot (2D) or integer (1D)
  if len(y_data.shape) > 1 and y_data.shape[1] > 1:
    y_true = np.argmax(y_data, axis=1)
  else:
    y_true = y_data

  n_outputs = len(np.unique(y_true))


  # Find index of minimum best stopping metric
  if 'early_stopping_metric' in INFO:
    if INFO['early_stopping_metric'] is not None:
      if INFO['early_stopping_metric'] in ['val_f1score', 'val_recall']:
        best_epoch = np.argmax(model.history.history['val_f1score']) + 1
        stopped_epoch = len(model.history.history['val_f1score'])
      elif INFO['early_stopping_metric'] == 'val_loss':
        best_epoch = np.argmin(model.history.history['val_loss']) + 1
        stopped_epoch = len(model.history.history['val_loss'])
    else:
      best_epoch = 'NA'
      stopped_epoch = 'NA'
  else:
    best_epoch = 'NA'
    stopped_epoch = 'NA'

  # 2. Generate Classification Report
  report = classification_report(y_true, y_pred, target_names=target_names[:n_outputs], zero_division=0)
  f1_macro = f1_score(y_true, y_pred, average='macro', zero_division=0)

  # Ensure the directory exists
  directory = f'{save_folder}/partial'
  if not os.path.exists(directory):
    os.makedirs(directory)

  # Save report to text file
  report_filename = f'{directory}/report_{suffix}_{INFO["dataset"]}_{INFO["model_type"]}.txt'
  with open(report_filename, "a") as f:
    f.write(f'Report for dataset: {INFO["dataset"]}. Model: {INFO["model_type"]}. Fold: {fold}.\n')
    f.write(f"Training Info: Stopped at Epoch {stopped_epoch}, Best Epoch was {best_epoch}\n")
    f.write(f"Macro F1-Score: {f1_macro:.4f}\n")
    f.write("-" * 30 + "\n")
    f.write(report)
    f.write("\n")

  # 3. Generate and Save Confusion Matrix Plot with Ratios
  cm = confusion_matrix(y_true, y_pred)

  # Calculate ratios (normalization by row/actual class total)
  # Handling potential division by zero if a class is empty in a specific fold
  row_sums = cm.sum(axis=1)[:, np.newaxis]
  cm_ratios = np.divide(cm.astype('float'), row_sums, out=np.zeros_like(cm, dtype=float), where=row_sums!=0)

  # Create annotation labels: "Count (Ratio)"
  labels = (np.array(["{0:d}\n({1:.2f})".format(count, ratio)
    for count, ratio in zip(cm.flatten(), cm_ratios.flatten())]
  )).reshape(cm.shape)

  plt.figure(figsize=figure_size)

  # FIX: We now pass cm_ratios to the heatmap for color intensity (grading)
  # vmin and vmax ensure the color bar scale is always 0.0 to 1.0 (0% to 100%)
  res = sns.heatmap(cm_ratios, annot=labels, fmt="", cmap='Greens',
    xticklabels=target_names[:n_outputs],
    yticklabels=target_names[:n_outputs],
    vmin=0, vmax=1, annot_kws={"size": font_size})

  # Access the color bar from the heatmap and set the tick size
  cbar = res.collections[0].colorbar
  cbar.ax.tick_params(labelsize=font_size)

  plt.title(f'Confusion Matrix: {suffix}. Dataset: {INFO["dataset"]}. Model: {INFO["model_type"]}. Fold {fold}. Best Epoch: {best_epoch}', fontsize=font_size)
  plt.ylabel('Actual Label', fontsize=font_size)
  plt.xlabel('Predicted Label', fontsize=font_size)


  # Set tick labels font size
  plt.xticks(fontsize=font_size)
  plt.yticks(fontsize=font_size)


  # Save figure as PDF
  plot_filename = f'{save_folder}/partial/matrix_{suffix}_{INFO["dataset"]}_{INFO["model_type"]}_{fold}.pdf'
  plt.savefig(plot_filename, format='pdf', bbox_inches='tight')
  plt.close()
  return
########################## Function End ######################################

########################## Function Start ######################################
def save_finish(INFO, cross_testing=False):
  if cross_testing: folder= this.CROSS_TEST_FOLDER
  else: folder = this.RESULT_FOLDER
  os.makedirs(folder, exist_ok=True)
  save_folder = f'{folder}/partial'
  os.makedirs(save_folder, exist_ok=True)
  now = datetime.now(this.TIME_ZONE).strftime("%Y%m%d~%H%M%S")
  INFO['time_stamp'] = now

  # saving current time-stamp
  with open(f'{save_folder}/info.json', "w") as f: json.dump(INFO, f)
  final_folder = f'{folder}/{INFO["dataset"]}~{INFO["model_type"]}~{now}'
  os.rename(save_folder, final_folder)
  return
########################## Function End ######################################

########################## Function Start ######################################
def rename_partial():
  partial_folder = f'{this.RESULT_FOLDER}/partial'
  with open(f'{partial_folder}/info.json', "r") as f: INFO = json.load(f)
  final_folder = f'{this.RESULT_FOLDER}/partial~{INFO["dataset"]}~{INFO["model_type"]}~{INFO["time_stamp"]}'
  os.rename(partial_folder, final_folder)
  print('Existing partial folder renamed')
  return
########################## Function End ######################################

########################## Function Start ######################################
def focal_loss(gamma=2.0, alpha=0.25):
  def focal_loss_fixed(y_true, y_pred):
    epsilon = K.epsilon()
    y_pred = K.clip(y_pred, epsilon, 1.0 - epsilon)
    cross_entropy = -y_true * K.log(y_pred)
    loss = alpha * K.pow(1.0 - y_pred, gamma) * cross_entropy
    return K.mean(K.sum(loss, axis=-1))
  return focal_loss_fixed
########################## Function End ######################################

########### need these for ShallowConvNet
def square(x):
  return K.square(x)

def log(x):
  return K.log(K.clip(x, min_value=1e-7, max_value=10000))
########################## Function End ######################################

########################## Function Start ######################################
def fix_time_dimension(x_data, target_samples):
  current_samples = x_data.shape[1]
  if current_samples == target_samples: return x_data
  if current_samples > target_samples:  return x_data[:, :target_samples, :, :]
  else:
    # Case: Extend (e.g., 249 -> 250)
    # Using 'edge' mode repeats the last value along the specified axis
    padding_size = target_samples - current_samples

    # Define pad_width for 4D: (segments, time, channels, bands)
    # (0, padding_size) on axis 1 means we only extend the time dimension at the end
    pad_width = [(0, 0), (0, padding_size), (0, 0), (0, 0)]

    # mode='edge' pads with the last value of the array along that axis
    return np.pad(x_data, pad_width=pad_width, mode='edge')
########################## Function End ######################################

########################## Function Start ######################################
def get_seed():
  return int(time.time()*10) % 1000000
########################## Function End ######################################

########################## Function Start ######################################
def play_audio():
  from IPython.display import Audio, display
  url = "https://upload.wikimedia.org/wikipedia/commons/4/42/Bird_singing.ogg"
  # This embeds the player directly into the notebook's output structure
  display(Audio(url=url, autoplay=True))
########################## Function End ######################################

########################## Function Start ######################################
def import_dataset(INFO):
  # set sampling frequency
  try:
    if INFO['resample_freq'] is None:
      INFO['sampling_freq'] = COLEEG.Sample_Freqs[INFO['dataset']]
    else:
      INFO['sampling_freq'] = INFO['resample_freq']
  except KeyError:
    INFO['sampling_freq'] = COLEEG.Sample_Freqs[INFO['dataset']]

  start_time = time.time()

  # loading data
  if INFO['dataset'] == 'bcicomptIV2a':
    import warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning) # disable annoying error messages from python
    data_x, data_y, data_subject_index = get_data_bcicomptIV2a(resample_freq=INFO['resample_freq'], Exclude=np.array(INFO['exclude']), Bands=INFO['band_filters'], tmin=INFO['tmin'], tmax=(INFO['tmax']-1/INFO['sampling_freq']), Baseline=None)
  elif INFO['dataset'] == 'physionet':
    data_x, data_y, data_subject_index = get_data_physionet(resample_freq=INFO['resample_freq'], Exclude=np.array(INFO['exclude']), Tasks=np.array(INFO['tasks']), Bands=INFO['band_filters'],  tmin=INFO['tmin'], tmax=(INFO['tmax']-1/INFO['sampling_freq']), Baseline=None, notch_freqs=INFO['notch_freqs'])
  elif INFO['dataset'] == 'ttk':
    data_x, data_y, data_subject_index = get_data_ttk(resample_freq=INFO['resample_freq'], Exclude=np.array(INFO['exclude']), Bands=INFO['band_filters'], tmin=INFO['tmin'], tmax=(INFO['tmax']-1/INFO['sampling_freq']), Baseline=None)
  elif INFO['dataset'] == 'chbmit':
    data_x, data_y, data_subject_index = get_data_chbmit(resample_freq=INFO['resample_freq'], Bands=INFO['band_filters'], tmin=INFO['tmin'], tmax=INFO['tmax'], gap = INFO['gap'], segment_max=INFO['segment_max'], Baseline=None)
  elif INFO['dataset'] == 'mitbih':
    data_x, data_y, data_subject_index = get_data_mitbih(INFO['beat_classes'],INFO['beat_samples'], channels=INFO['channels'])
  elif INFO['dataset'] == 'incart':
    data_x, data_y, data_subject_index = get_data_incart(INFO['beat_classes'],INFO['beat_samples'], channels=INFO['channels'])
  elif INFO['dataset'] == 'ptbxl':
    data_x, data_y, data_subject_index = get_data_ptbxl(INFO['beat_classes'],INFO['beat_samples'], channels=INFO['channels'])
  else:
    raise Exception(f"{INFO['dataset']}: wrong dataset")

  INFO['bands'] = data_x.shape[-1]
  print(f"\n{INFO['dataset']} import time: {timedelta(seconds=round(time.time() - start_time))}")
  return data_x, data_y, data_subject_index

########################## Function End ######################################
