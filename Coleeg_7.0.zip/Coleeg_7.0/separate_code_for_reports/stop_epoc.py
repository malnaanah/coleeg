import os
import re
import numpy as np
import math

def format_to_mmss(seconds):
  """Converts seconds into mm:ss format."""
  if math.isnan(seconds) or seconds is None:
    return "--:--"
  minutes = int(seconds // 60)
  secs = int(seconds % 60)
  return f"{minutes:02d}:{secs:02d}"

def calculate_full_mean_stats(base_path="."):
  all_results = {}
  global_times = []
  global_epochs = []
  epoch_pattern = re.compile(r"Stopped at Epoch\s+(\d+)")

  folders = sorted([d for d in os.listdir(base_path) if os.path.isdir(os.path.join(base_path, d)) and "ECG1D" in d])

  for folder in folders:
    folder_path = os.path.join(base_path, folder)
    f_times = []
    f_epochs = []

    t_path = os.path.join(folder_path, "time.csv")
    if os.path.exists(t_path):
      with open(t_path, 'r') as f:
        content = f.read().strip()
        if content:
          f_times = [float(t) for t in content.split(',')]
          global_times.extend(f_times)

    report_files = [f for f in os.listdir(folder_path) if f.startswith("report_testing")]
    for r_file in report_files:
      with open(os.path.join(folder_path, r_file), 'r') as f:
        matches = epoch_pattern.findall(f.read())
        f_epochs.extend([int(m) for m in matches])
        global_epochs.extend([int(m) for m in matches])

    if f_times or f_epochs:
      all_results[folder] = {
        "count": len(f_times) if f_times else len(f_epochs),
        "t_min": np.min(f_times) if f_times else np.nan,
        "t_mean": np.mean(f_times) if f_times else np.nan,
        "t_max": np.max(f_times) if f_times else np.nan,
        "t_std": np.std(f_times, ddof=1) if len(f_times) > 1 else np.nan,
        "e_min": np.min(f_epochs) if f_epochs else np.nan,
        "e_mean": np.mean(f_epochs) if f_epochs else np.nan,
        "e_max": np.max(f_epochs) if f_epochs else np.nan,
        "e_std": np.std(f_epochs, ddof=1) if len(f_epochs) > 1 else np.nan
      }

  return all_results, global_times, global_epochs

results, g_times, g_epochs = calculate_full_mean_stats()

# Updated Header to include SD
header = f"{'Folder Name':<40} | {'Folds':<5} | {'Time (Min/Mean/Max/SD)':<40} | {'Epoch (Min/Mean/Max/SD)'}"
print(header)
print("-" * len(header))

for folder, s in results.items():
  # Apply format_to_mmss to the standard deviation (t_std)
  t_range = f"{format_to_mmss(s['t_min'])} / {format_to_mmss(s['t_mean'])} / {format_to_mmss(s['t_max'])} / {format_to_mmss(s['t_std'])}"
  e_range = f"{s['e_min']:>3.0f} / {s['e_mean']:>3.0f} / {s['e_max']:>3.0f} / {s['e_std']:>3.1f}"
  print(f"{folder[:40]:<40} | {s['count']:<5} | {t_range:<40} | {e_range}")

if g_times or g_epochs:
  print("\n" + "=" * len(header))
  g_t_std = np.std(g_times, ddof=1) if len(g_times) > 1 else np.nan
  g_e_std = np.std(g_epochs, ddof=1) if len(g_epochs) > 1 else np.nan

  gt_range = f"{format_to_mmss(np.min(g_times))} / {format_to_mmss(np.mean(g_times))} / {format_to_mmss(np.max(g_times))} / {format_to_mmss(g_t_std)}"
  ge_range = f"{np.min(g_epochs):>3.0f} / {np.mean(g_epochs):>3.0f} / {np.max(g_epochs):>3.0f} / {g_e_std:>3.1f}"
  print(f"{'GRAND TOTALS (Min/Mean/Max/SD)':<40} | {len(g_times):<5} | {gt_range:<40} | {ge_range}")
  print("=" * len(header))
