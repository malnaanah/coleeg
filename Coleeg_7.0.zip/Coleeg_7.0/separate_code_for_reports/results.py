import os
import re
import pandas as pd

def parse_report_file(file_path, eval_id):
  """Parses a single report file and returns data for N, S, V classes."""
  results = []

  if not os.path.exists(file_path):
    return results

  with open(file_path, 'r') as f:
    content = f.read()

  # Regex: Class (N/S/V), Precision, Recall, F1, Support
  table_regex = r'^\s+([NSV])\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+(\d+)'

  # Handle multiple folds per file if present
  report_sections = re.split(r'Report for dataset:', content)[1:]
  if not report_sections:
    report_sections = [content]

  for section in report_sections:
    fold_match = re.search(r'Fold:?\s*(\d+)', section)
    fold_label = fold_match.group(1) if fold_match else "0"

    for line in section.split('\n'):
      match = re.search(table_regex, line)
      if match:
        results.append({
          'Evaluation': eval_id,
          'Fold': fold_label,
          'Class': match.group(1).strip(),
          'Precision': float(match.group(2)),
          'Recall': float(match.group(3)),
          'F1-Score': float(match.group(4)),
          'Support': int(match.group(5))
        })
  return results

def process_evaluations():
  """Processes subfolders and generates combined Metric+Support CSVs."""
  all_data = []

  # Scan current directory for evaluation subfolders
  subfolders = [d for d in os.listdir('.') if os.path.isdir(d) and not d.startswith('.')]

  for folder in subfolders:
    for file in os.listdir(folder):
      if file.endswith(".txt") and "report_testing" in file:
        file_path = os.path.join(folder, file)

        # Identify E1, E2, etc. from folder name
        eval_label_match = re.search(r'_E(\d+)', folder)
        eval_label = f"E{eval_label_match.group(1)}" if eval_label_match else folder

        all_data.extend(parse_report_file(file_path, eval_label))

  if not all_data:
    print("No relevant report data found.")
    return

  df = pd.DataFrame(all_data)
  metrics = ['Precision', 'Recall', 'F1-Score']

  for metric in metrics:
    # Create a pivot for the Metric and a pivot for the Support
    pivot_metric = df.pivot_table(index=['Evaluation', 'Fold'], columns='Class', values=metric)
    pivot_support = df.pivot_table(index=['Evaluation', 'Fold'], columns='Class', values='Support')

    # Rename columns to distinguish between Metric and Support (e.g., N_F1, N_Support)
    pivot_metric.columns = [f"{c}_{metric}" for c in pivot_metric.columns]
    pivot_support.columns = [f"{c}_Support" for c in pivot_support.columns]

    # Combine them side-by-side
    combined = pd.concat([pivot_metric, pivot_support], axis=1)

    # Reorder columns so N_Metric is next to N_Support
    ordered_cols = []
    for cls in ['N', 'S', 'V']:
      if f"{cls}_{metric}" in combined.columns:
        ordered_cols.extend([f"{cls}_{metric}", f"{cls}_Support"])

    combined = combined[ordered_cols]

    output_name = f"metrics_{metric.lower()}_with_support.csv"
    combined.to_csv(output_name)
    print(f"Generated: {output_name}")

if __name__ == "__main__":
  process_evaluations()
